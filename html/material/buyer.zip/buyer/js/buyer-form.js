// Buyer Form - Main form handling and API interactions

const BuyerForm = {
    apiBaseUrl: '../api',
    csrfToken: null,
    
    // Initialize the buyer form
    init() {
        this.getCSRFToken();
        this.bindEvents();
        this.initializeDropdowns();
        this.setupFormInteractions();
    },

    // Get CSRF token
    getCSRFToken() {
        const metaTag = document.querySelector('meta[name="csrf-token"]');
        if (metaTag) {
            this.csrfToken = metaTag.getAttribute('content');
        } else {
            // Generate a new CSRF token if not found
            this.generateCSRFToken();
        }
    },

    // Generate CSRF token
    generateCSRFToken() {
        fetch(`${this.apiBaseUrl}/csrf-token`)
            .then(response => response.json())
            .then(data => {
                this.csrfToken = data.token;
            })
            .catch(error => {
                console.error('Error fetching CSRF token:', error);
            });
    },

    // Bind form events
    bindEvents() {
        // Set current date for signature
        const signatureDateInput = document.getElementById('signatureDate');
        if (signatureDateInput) {
            signatureDateInput.value = DateUtils.getCurrentDate();
        }

        // Phone number formatting
        this.setupPhoneFormatting();
        
        // Currency formatting
        this.setupCurrencyFormatting();
        
        // Real-time validation enhancements
        this.setupRealTimeValidation();
    },

    // Initialize dropdown data
    initializeDropdowns() {
        populateDropdowns();
        
        // Set up region-town dependencies
        this.setupRegionTownDependencies();
    },

    // Setup form interactions
    setupFormInteractions() {
        // Auto-populate spouse details based on marital status
        this.setupMaritalStatusInteractions();
        
        // Employment type specific handling
        this.setupEmploymentTypeInteractions();
        
        // Property value calculations
        this.setupPropertyCalculations();
        
        // Document upload previews
        this.setupDocumentPreviews();
    },

    // Setup phone number formatting
    setupPhoneFormatting() {
        const phoneInputs = document.querySelectorAll('input[type="tel"]');
        phoneInputs.forEach(input => {
            input.addEventListener('input', (e) => {
                const formatted = formatPhoneNumber(e.target.value);
                if (formatted !== e.target.value) {
                    e.target.value = formatted;
                }
            });
        });
    },

    // Setup currency formatting
    setupCurrencyFormatting() {
        const currencyInputs = document.querySelectorAll('#propertyValue, #downPayment, #loanAmount, #monthlyIncome');
        currencyInputs.forEach(input => {
            input.addEventListener('blur', (e) => {
                const value = parseFloat(e.target.value.replace(/[^\d.]/g, ''));
                if (!isNaN(value)) {
                    e.target.value = value.toFixed(2);
                }
            });

            input.addEventListener('focus', (e) => {
                // Remove formatting for easier editing
                const value = e.target.value.replace(/[^\d.]/g, '');
                e.target.value = value;
            });
        });
    },

    // Setup real-time validation enhancements
    setupRealTimeValidation() {
        // ID number validation based on type
        const idTypeSelect = document.getElementById('idType');
        const idNumberInput = document.getElementById('idNumber');
        
        if (idTypeSelect && idNumberInput) {
            idTypeSelect.addEventListener('change', () => {
                FormValidation.validateField(idNumberInput);
            });
        }

        // Age calculation and display
        const dobInput = document.getElementById('dateOfBirth');
        if (dobInput) {
            dobInput.addEventListener('change', (e) => {
                const age = DateUtils.calculateAge(e.target.value);
                const ageDisplay = document.getElementById('ageDisplay');
                if (ageDisplay) {
                    ageDisplay.textContent = `Age: ${age} years`;
                    ageDisplay.className = age >= 18 ? 'text-success small' : 'text-danger small';
                }
            });
        }
    },

    // Setup region-town dependencies
    setupRegionTownDependencies() {
        // Main address region-town
        const regionSelect = document.getElementById('region');
        if (regionSelect) {
            regionSelect.addEventListener('change', (e) => {
                this.updateTownDropdown('town', e.target.value);
            });
        }

        // Next of kin region-town
        const nokRegionSelect = document.getElementById('nokRegion');
        if (nokRegionSelect) {
            nokRegionSelect.addEventListener('change', (e) => {
                this.updateTownDropdown('nokTown', e.target.value);
            });
        }

        // Preferred areas region-town
        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('preferred-region')) {
                const areaItem = e.target.closest('.preferred-area-item');
                const townSelect = areaItem.querySelector('.preferred-town');
                this.updateTownDropdown(townSelect, e.target.value);
            }
        });
    },

    // Update town dropdown based on region
    updateTownDropdown(townSelectOrId, regionValue) {
        let townSelect;
        if (typeof townSelectOrId === 'string') {
            townSelect = document.getElementById(townSelectOrId);
        } else {
            townSelect = townSelectOrId;
        }

        if (townSelect && regionValue) {
            townSelect.innerHTML = '<option value="">Select Town</option>';
            
            const towns = FormData.townsByRegion[regionValue] || [];
            towns.forEach(town => {
                const option = document.createElement('option');
                option.value = town;
                option.textContent = town;
                townSelect.appendChild(option);
            });
        }
    },

    // Setup marital status interactions
    setupMaritalStatusInteractions() {
        const maritalStatusSelect = document.getElementById('maritalStatus');
        if (maritalStatusSelect) {
            maritalStatusSelect.addEventListener('change', (e) => {
                const isMarried = e.target.value === 'married';
                this.toggleSpouseFields(isMarried);
                
                // Update document requirements
                this.updateDocumentRequirements();
            });
        }
    },

    // Toggle spouse fields visibility and requirements
    toggleSpouseFields(show) {
        const spouseSection = document.getElementById('spouseDetails');
        const spouseFields = spouseSection.querySelectorAll('input, select');
        
        if (show) {
            spouseSection.classList.remove('d-none');
            spouseFields.forEach(field => {
                if (['spouseFullName', 'spouseIdPassport', 'spouseDateOfBirth'].includes(field.id)) {
                    field.setAttribute('required', 'required');
                }
            });
        } else {
            spouseSection.classList.add('d-none');
            spouseFields.forEach(field => {
                field.removeAttribute('required');
                field.value = '';
                FormValidation.clearFieldValidation(field);
            });
        }
    },

    // Setup employment type interactions
    setupEmploymentTypeInteractions() {
        const employmentTypeSelect = document.getElementById('employmentType');
        if (employmentTypeSelect) {
            employmentTypeSelect.addEventListener('change', (e) => {
                this.handleEmploymentTypeChange(e.target.value);
            });
        }
    },

    // Handle employment type change
    handleEmploymentTypeChange(employmentType) {
        const employmentDetails = document.getElementById('employmentDetails');
        const employmentFields = employmentDetails.querySelectorAll('input, select, textarea');
        
        if (employmentType === 'unemployed') {
            employmentDetails.style.opacity = '0.6';
            employmentFields.forEach(field => {
                field.removeAttribute('required');
                if (field.id !== 'monthlyIncome') {
                    field.disabled = true;
                }
            });
        } else if (employmentType === 'pensioner') {
            employmentDetails.style.opacity = '1';
            employmentFields.forEach(field => {
                field.disabled = false;
                if (['monthlyIncome'].includes(field.id)) {
                    field.setAttribute('required', 'required');
                }
            });
        } else {
            employmentDetails.style.opacity = '1';
            employmentFields.forEach(field => {
                field.disabled = false;
                if (['employerName', 'monthlyIncome'].includes(field.id)) {
                    field.setAttribute('required', 'required');
                }
            });
        }
    },

    // Setup property calculations
    setupPropertyCalculations() {
        const propertyValueInput = document.getElementById('propertyValue');
        const downPaymentInput = document.getElementById('downPayment');
        const loanAmountInput = document.getElementById('loanAmount');

        if (propertyValueInput && downPaymentInput && loanAmountInput) {
            const calculateLoan = () => {
                const propertyValue = parseFloat(propertyValueInput.value) || 0;
                const downPayment = parseFloat(downPaymentInput.value) || 0;
                const loanAmount = Math.max(0, propertyValue - downPayment);
                
                loanAmountInput.value = loanAmount.toFixed(2);
                
                // Show loan percentage
                const loanPercentage = propertyValue > 0 ? (loanAmount / propertyValue * 100).toFixed(1) : 0;
                this.updateLoanInfo(loanAmount, loanPercentage);
            };

            propertyValueInput.addEventListener('input', calculateLoan);
            downPaymentInput.addEventListener('input', calculateLoan);
        }
    },

    // Update loan information display
    updateLoanInfo(loanAmount, loanPercentage) {
        let loanInfoElement = document.getElementById('loanInfo');
        if (!loanInfoElement) {
            loanInfoElement = document.createElement('div');
            loanInfoElement.id = 'loanInfo';
            loanInfoElement.className = 'mt-2 small text-muted';
            document.getElementById('loanAmount').parentNode.appendChild(loanInfoElement);
        }
        
        loanInfoElement.innerHTML = `
            <i class="fas fa-info-circle me-1"></i>
            Loan: ${formatCurrency(loanAmount)} (${loanPercentage}% of property value)
        `;
    },

    // Setup document previews
    setupDocumentPreviews() {
        document.addEventListener('change', (e) => {
            if (e.target.type === 'file') {
                this.handleFilePreview(e.target);
            }
        });
    },

    // Handle file preview
    handleFilePreview(fileInput) {
        const files = Array.from(fileInput.files);
        files.forEach(file => {
            if (file.type.startsWith('image/')) {
                this.createImagePreview(file, fileInput);
            }
        });
    },

    // Create image preview
    createImagePreview(file, fileInput) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const previewContainer = fileInput.closest('[data-doc-type]').querySelector('.file-list');
            const preview = document.createElement('div');
            preview.className = 'file-preview mt-2';
            preview.innerHTML = `
                <img src="${e.target.result}" alt="Preview" style="max-width: 200px; max-height: 150px; border-radius: 4px;">
            `;
            previewContainer.appendChild(preview);
        };
        reader.readAsDataURL(file);
    },

    // Update document requirements based on form data
    updateDocumentRequirements() {
        const maritalStatus = document.getElementById('maritalStatus').value;
        const marriageCertSection = document.querySelector('[data-doc-type="marriage_certificate"]');
        
        if (marriageCertSection) {
            const label = marriageCertSection.querySelector('h6');
            if (maritalStatus === 'married') {
                label.innerHTML = 'Marriage Certificate <span class="text-danger">*</span>';
                marriageCertSection.querySelector('input').setAttribute('required', 'required');
            } else {
                label.innerHTML = 'Marriage Certificate (if married)';
                marriageCertSection.querySelector('input').removeAttribute('required');
            }
        }
    },

    // Submit application
    async submitApplication() {
        try {
            this.showLoadingOverlay();
            
            // Prepare form data
            const formData = this.prepareFormData();
            
            // Submit to API
            const response = await fetch(`${this.apiBaseUrl}/applications/buyers`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.csrfToken
                },
                body: JSON.stringify(formData)
            });

            const result = await response.json();

            if (response.ok && result.success) {
                this.handleSubmissionSuccess(result);
            } else {
                this.handleSubmissionError(result.error || 'Submission failed');
            }

        } catch (error) {
            console.error('Submission error:', error);
            this.handleSubmissionError('Network error occurred. Please try again.');
        } finally {
            this.hideLoadingOverlay();
        }
    },

    // Prepare form data for submission
    prepareFormData() {
        const form = document.getElementById('buyerApplicationForm');
        const formData = new FormData(form);
        const data = {};

        // Convert FormData to object
        for (let [key, value] of formData.entries()) {
            if (data[key]) {
                if (Array.isArray(data[key])) {
                    data[key].push(value);
                } else {
                    data[key] = [data[key], value];
                }
            } else {
                data[key] = value;
            }
        }

        // Process preferred areas
        data.preferredAreas = this.processPreferredAreas(data);

        // Process declarations
        data.declarations = this.processDeclarations(data);

        // Clean up unnecessary fields
        this.cleanupFormData(data);

        return data;
    },

    // Process preferred areas data
    processPreferredAreas(data) {
        const areas = [];
        const regions = data['preferredRegion[]'] || [];
        const towns = data['preferredTown[]'] || [];
        const locations = data['preferredLocation[]'] || [];
        const suburbs = data['preferredSuburb[]'] || [];

        const regionsArray = Array.isArray(regions) ? regions : [regions];
        
        regionsArray.forEach((region, index) => {
            if (region) {
                areas.push({
                    region: region,
                    town: Array.isArray(towns) ? towns[index] : towns,
                    location: Array.isArray(locations) ? locations[index] : locations,
                    suburb: Array.isArray(suburbs) ? suburbs[index] : suburbs
                });
            }
        });

        return areas;
    },

    // Process declarations data
    processDeclarations(data) {
        const declarations = data['declarations'] || [];
        return Array.isArray(declarations) ? declarations : [declarations];
    },

    // Clean up form data
    cleanupFormData(data) {
        // Remove array notation from keys
        const arrayKeys = Object.keys(data).filter(key => key.includes('[]'));
        arrayKeys.forEach(key => {
            delete data[key];
        });

        // Convert string numbers to numbers
        const numericFields = ['propertyValue', 'downPayment', 'loanAmount', 'monthlyIncome'];
        numericFields.forEach(field => {
            if (data[field]) {
                data[field] = parseFloat(data[field]) || 0;
            }
        });
    },

    // Handle successful submission
    handleSubmissionSuccess(result) {
        // Clear saved form data
        localStorage.removeItem('nuru-buyer-form-data');
        localStorage.removeItem('nuru-buyer-current-step');
        
        // Show success modal
        const successModal = new bootstrap.Modal(document.getElementById('successModal'));
        document.getElementById('applicationNumber').textContent = result.application_number;
        successModal.show();
        
        // Track submission for analytics
        this.trackSubmission(result);
    },

    // Handle submission error
    handleSubmissionError(errorMessage) {
        const alertHtml = `
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Submission Failed:</strong> ${errorMessage}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        const currentStep = document.getElementById(`step-${FormSteps.currentStep}`);
        currentStep.insertAdjacentHTML('afterbegin', alertHtml);
        
        // Scroll to top to show error
        currentStep.scrollIntoView({ behavior: 'smooth', block: 'start' });
    },

    // Show loading overlay
    showLoadingOverlay() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.remove('d-none');
        }
    },

    // Hide loading overlay
    hideLoadingOverlay() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.add('d-none');
        }
    },

    // Track submission for analytics
    trackSubmission(result) {
        // Implementation for analytics tracking
        console.log('Application submitted:', result.application_number);
        
        // Could integrate with Google Analytics, etc.
        if (typeof gtag !== 'undefined') {
            gtag('event', 'application_submit', {
                'event_category': 'buyer_application',
                'event_label': result.application_number
            });
        }
    },

    // Export form data for debugging
    exportFormData() {
        const formData = this.prepareFormData();
        console.log('Form Data:', formData);
        
        // Create downloadable JSON file
        const dataStr = JSON.stringify(formData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = 'buyer-application-data.json';
        link.click();
        
        URL.revokeObjectURL(url);
    },

    // Validate required documents before submission
    validateDocuments() {
        const requiredDocs = ['id_passport', 'proof_of_income', 'bank_statements'];
        const maritalStatus = document.getElementById('maritalStatus').value;
        
        if (maritalStatus === 'married') {
            requiredDocs.push('marriage_certificate');
        }
        
        const missingDocs = [];
        
        requiredDocs.forEach(docType => {
            const fileInput = document.querySelector(`input[name="${docType}"]`);
            if (!fileInput || fileInput.files.length === 0) {
                missingDocs.push(FormData.documentTypes[docType].label);
            }
        });
        
        if (missingDocs.length > 0) {
            FormValidation.showAlert(
                `Please upload the following required documents: ${missingDocs.join(', ')}`,
                'danger'
            );
            return false;
        }
        
        return true;
    },

    // Save form as draft
    saveAsDraft() {
        const formData = this.prepareFormData();
        formData.status = 'draft';
        
        fetch(`${this.apiBaseUrl}/applications/buyers/draft`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': this.csrfToken
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                FormValidation.showAlert('Application saved as draft successfully!', 'success');
            }
        })
        .catch(error => {
            console.error('Error saving draft:', error);
            FormValidation.showAlert('Error saving draft. Please try again.', 'danger');
        });
    }
};

// Initialize buyer form when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    BuyerForm.init();
});

// Add global keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl+S to save as draft
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        BuyerForm.saveAsDraft();
    }
    
    // Ctrl+E to export form data (for debugging)
    if (e.ctrlKey && e.key === 'e') {
        e.preventDefault();
        BuyerForm.exportFormData();
    }
});

// Handle page unload warning if form has data
window.addEventListener('beforeunload', function(e) {
    const hasFormData = localStorage.getItem('nuru-buyer-form-data');
    if (hasFormData) {
        e.preventDefault();
        e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
        return e.returnValue;
    }
});
