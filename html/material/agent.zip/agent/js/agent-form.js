/**
 * Nuru Agent Form - Portal Integration JavaScript with Advanced Security
 * Author: MiniMax Agent
 */

class AgentForm {
    constructor() {
        this.currentStep = 1;
        this.totalSteps = 5;
        this.formData = {};
        this.uploadedFiles = {};
        this.towns = [];
        this.countries = [];
        this.csrfTokens = {}; // Support for multiple CSRF tokens
        this.sessionId = '';
        this.portalBaseUrl = '../';
        this.securityEnabled = true;
        this.rateLimitEnabled = true;
        this.fileSecurityEnabled = true;
        
        // Request tracking for rate limiting awareness
        this.requestCount = 0;
        this.lastRequestTime = 0;
        
        // Initialize the form
        this.init();
        
        // Make form globally accessible
        window.agentForm = this;
    }
    
    async init() {
        try {
            // Show loading overlay
            this.showLoading();
            
            // Check security settings from form
            this.checkSecuritySettings();
            
            // Initialize form data
            await this.initializeForm();
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Update UI
            this.updateStepProgress();
            this.updateNavigation();
            
            // Load existing form data if any
            this.loadFormData();
            
            // Hide loading overlay
            this.hideLoading();
            
            // Log successful initialization
            console.log('Agent form initialized with security features:', {
                security: this.securityEnabled,
                rateLimit: this.rateLimitEnabled,
                fileSecurity: this.fileSecurityEnabled
            });
            
        } catch (error) {
            console.error('Form initialization error:', error);
            this.showToast('Error', 'Failed to initialize form. Please refresh the page.', 'danger');
            this.hideLoading();
        }
    }
    }
    
    async initializeForm() {
        try {
            const response = await this.makeRequest('init', {});
            
            if (response.success) {
                this.sessionId = response.session_id;
                this.currentStep = response.current_step;
                this.csrfToken = response.csrf_token;
                this.towns = response.towns || [];
                this.countries = response.countries || [];
                this.formData = response.form_data || {};
                this.uploadedFiles = response.uploaded_files || [];
                
                // Update CSRF token in form
                document.getElementById('csrfToken').value = this.csrfToken;
                
                // Populate dropdowns
                this.populateCountries();
                this.populateTowns();
                
                return true;
            } else {
                throw new Error(response.message || 'Initialization failed');
            }
        } catch (error) {
            throw new Error('Failed to initialize form: ' + error.message);
        }
    }
    
    setupEventListeners() {
        // Navigation buttons
        document.getElementById('nextBtn').addEventListener('click', () => this.nextStep());
        document.getElementById('prevBtn').addEventListener('click', () => this.previousStep());
        document.getElementById('submitBtn').addEventListener('click', (e) => {
            e.preventDefault();
            this.submitForm();
        });
        
        // Step indicators
        document.querySelectorAll('.step-item').forEach((stepItem, index) => {
            stepItem.addEventListener('click', () => {
                const stepNumber = index + 1;
                if (stepNumber <= this.currentStep || stepItem.classList.contains('completed')) {
                    this.goToStep(stepNumber);
                }
            });
        });
        
        // Town change events for auto-fill region
        const townSelects = ['res_town', 'kin_town', 'emp_town'];
        townSelects.forEach(selectId => {
            const select = document.getElementById(selectId);
            if (select) {
                select.addEventListener('change', (e) => {
                    const regionId = selectId.replace('town', 'region');
                    this.autoFillRegion(e.target.value, regionId);
                });
            }
        });
        
        // Currency input formatting
        document.querySelectorAll('.currency-input').forEach(input => {
            input.addEventListener('input', (e) => this.formatCurrency(e.target));
            input.addEventListener('blur', (e) => this.formatCurrency(e.target));
        });
        
        // File upload handlers
        document.querySelectorAll('.file-input').forEach(input => {
            input.addEventListener('change', (e) => this.handleFileSelect(e));
        });
        
        // Drag and drop for file uploads
        document.querySelectorAll('.file-upload-label').forEach(label => {
            label.addEventListener('dragover', (e) => {
                e.preventDefault();
                label.style.backgroundColor = 'rgba(13, 71, 161, 0.1)';
            });
            
            label.addEventListener('dragleave', (e) => {
                e.preventDefault();
                label.style.backgroundColor = '';
            });
            
            label.addEventListener('drop', (e) => {
                e.preventDefault();
                label.style.backgroundColor = '';
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    const input = label.previousElementSibling;
                    input.files = files;
                    input.dispatchEvent(new Event('change'));
                }
            });
        });
        
        // Remove file buttons
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('remove-file') || e.target.parentElement.classList.contains('remove-file')) {
                const button = e.target.classList.contains('remove-file') ? e.target : e.target.parentElement;
                this.removeFile(button);
            }
        });
        
        // Form validation on input
        document.querySelectorAll('input, select, textarea').forEach(input => {
            input.addEventListener('blur', () => this.validateField(input));
            input.addEventListener('input', () => this.clearFieldError(input));
        });
        
        // Prevent form submission on Enter key
        document.getElementById('agentForm').addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && e.target.type !== 'submit') {
                e.preventDefault();
            }
        });
    }
    
    populateCountries() {
        const select = document.getElementById('nationality');
        if (select && this.countries.length > 0) {
            select.innerHTML = '<option value="">Select Nationality</option>';
            this.countries.forEach(country => {
                const option = document.createElement('option');
                option.value = country;
                option.textContent = country;
                select.appendChild(option);
            });
        }
    }
    
    populateTowns() {
        const townSelects = ['res_town', 'kin_town', 'emp_town'];
        
        townSelects.forEach(selectId => {
            const select = document.getElementById(selectId);
            if (select && this.towns.length > 0) {
                select.innerHTML = '<option value="">Select Town</option>';
                this.towns.forEach(town => {
                    const option = document.createElement('option');
                    option.value = town.town_name;
                    option.textContent = town.town_name;
                    option.dataset.region = town.region_name;
                    select.appendChild(option);
                });
            }
        });
    }
    
    async autoFillRegion(townName, regionInputId) {
        const regionInput = document.getElementById(regionInputId);
        if (!regionInput || !townName) return;
        
        try {
            const response = await this.makeRequest('get_region', {
                town: townName,
                csrf_token: this.csrfToken
            });
            
            if (response.success) {
                regionInput.value = response.region;
            }
        } catch (error) {
            console.error('Error getting region:', error);
        }
    }
    
    formatCurrency(input) {
        let value = input.value.replace(/[^\d.]/g, '');
        if (value) {
            // Ensure only one decimal point
            const parts = value.split('.');
            if (parts.length > 2) {
                value = parts[0] + '.' + parts.slice(1).join('');
            }
            
            // Format with commas
            const [integerPart, decimalPart] = value.split('.');
            const formattedInteger = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            
            input.value = decimalPart !== undefined ? 
                formattedInteger + '.' + decimalPart : 
                formattedInteger;
        }
    }
    
    async handleFileSelect(event) {
        const input = event.target;
        const file = input.files[0];
        const fileType = input.dataset.type;
        
        if (!file) return;
        
        // Validate file
        const validation = this.validateFile(file);
        if (!validation.valid) {
            this.showToast('Upload Error', validation.message, 'danger');
            input.value = '';
            return;
        }
        
        // Show upload progress
        const wrapper = input.closest('.file-upload-wrapper');
        const progressDiv = wrapper.querySelector('.upload-progress');
        const progressBar = progressDiv.querySelector('.progress-bar');
        const fileInfo = wrapper.querySelector('.file-info');
        const uploadLabel = wrapper.querySelector('.file-upload-label');
        
        // Hide upload label and file info, show progress
        uploadLabel.classList.add('d-none');
        fileInfo.classList.add('d-none');
        progressDiv.classList.remove('d-none');
        
        try {
            const result = await this.uploadFile(file, fileType, (progress) => {
                progressBar.style.width = progress + '%';
                progressBar.setAttribute('aria-valuenow', progress);
            });
            
            if (result.success) {
                // Show file info
                const filename = fileInfo.querySelector('.filename');
                filename.textContent = result.original_name;
                
                progressDiv.classList.add('d-none');
                fileInfo.classList.remove('d-none');
                
                // Store upload info
                this.uploadedFiles[fileType] = result;
                
                this.showToast('Success', 'File uploaded successfully', 'success');
            } else {
                throw new Error(result.message || 'Upload failed');
            }
        } catch (error) {
            console.error('File upload error:', error);
            this.showToast('Upload Error', error.message, 'danger');
            
            // Reset UI
            progressDiv.classList.add('d-none');
            uploadLabel.classList.remove('d-none');
            input.value = '';
        }
    }
    
    validateFile(file) {
        const maxSize = 10 * 1024 * 1024; // 10MB
        const allowedTypes = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'image/jpeg',
            'image/jpg',
            'image/png',
            'image/gif',
            'image/tiff',
            'image/bmp'
        ];
        
        if (file.size > maxSize) {
            return {
                valid: false,
                message: 'File size must be less than 10MB'
            };
        }
        
        if (!allowedTypes.includes(file.type)) {
            return {
                valid: false,
                message: 'Invalid file type. Please upload PDF, DOC, DOCX, or image files.'
            };
        }
        
        return { valid: true };
    }
    
    async uploadFile(file, fileType, progressCallback) {
        return new Promise((resolve, reject) => {
            const formData = new FormData();
            formData.append('action', 'upload_file');
            formData.append('file', file);
            formData.append('file_type', fileType);
            formData.append('csrf_token', this.csrfToken);
            
            const xhr = new XMLHttpRequest();
            
            xhr.upload.addEventListener('progress', (e) => {
                if (e.lengthComputable) {
                    const progress = Math.round((e.loaded / e.total) * 100);
                    progressCallback(progress);
                }
            });
            
            xhr.addEventListener('load', () => {
                try {
                    const response = JSON.parse(xhr.responseText);
                    resolve(response);
                } catch (error) {
                    reject(new Error('Invalid response from server'));
                }
            });
            
            xhr.addEventListener('error', () => {
                reject(new Error('Network error occurred'));
            });
            
            xhr.open('POST', 'ajax_handler.php');
            xhr.send(formData);
        });
    }
    
    removeFile(button) {
        const wrapper = button.closest('.file-upload-wrapper');
        const input = wrapper.querySelector('.file-input');
        const fileInfo = wrapper.querySelector('.file-info');
        const uploadLabel = wrapper.querySelector('.file-upload-label');
        const fileType = input.dataset.type;
        
        // Reset input and UI
        input.value = '';
        fileInfo.classList.add('d-none');
        uploadLabel.classList.remove('d-none');
        
        // Remove from uploaded files
        delete this.uploadedFiles[fileType];
        
        this.showToast('File Removed', 'File has been removed', 'info');
    }
    
    async nextStep() {
        if (await this.validateCurrentStep()) {
            if (await this.saveCurrentStep()) {
                if (this.currentStep < this.totalSteps) {
                    this.currentStep++;
                    this.goToStep(this.currentStep);
                }
            }
        }
    }
    
    previousStep() {
        if (this.currentStep > 1) {
            this.currentStep--;
            this.goToStep(this.currentStep);
        }
    }
    
    goToStep(stepNumber) {
        if (stepNumber < 1 || stepNumber > this.totalSteps) return;
        
        // Hide all steps
        document.querySelectorAll('.form-step').forEach(step => {
            step.classList.add('d-none');
        });
        
        // Show target step
        document.getElementById(`step-${stepNumber}`).classList.remove('d-none');
        
        // Update current step
        this.currentStep = stepNumber;
        
        // Update UI
        this.updateStepProgress();
        this.updateNavigation();
        
        // Update server-side step
        this.updateServerStep(stepNumber);
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    async updateServerStep(step) {
        try {
            await this.makeRequest('update_step', {
                step: step,
                csrf_token: this.csrfToken
            });
        } catch (error) {
            console.error('Error updating server step:', error);
        }
    }
    
    updateStepProgress() {
        document.querySelectorAll('.step-item').forEach((stepItem, index) => {
            const stepNumber = index + 1;
            
            stepItem.classList.remove('active', 'completed', 'clickable');
            
            if (stepNumber === this.currentStep) {
                stepItem.classList.add('active');
            } else if (stepNumber < this.currentStep) {
                stepItem.classList.add('completed', 'clickable');
            } else if (stepNumber <= this.currentStep) {
                stepItem.classList.add('clickable');
            }
        });
    }
    
    updateNavigation() {
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const submitBtn = document.getElementById('submitBtn');
        
        // Previous button
        prevBtn.disabled = this.currentStep === 1;
        
        // Next/Submit button
        if (this.currentStep === this.totalSteps) {
            nextBtn.classList.add('d-none');
            submitBtn.classList.remove('d-none');
        } else {
            nextBtn.classList.remove('d-none');
            submitBtn.classList.add('d-none');
        }
    }
    
    async validateCurrentStep() {
        const currentStepElement = document.getElementById(`step-${this.currentStep}`);
        const inputs = currentStepElement.querySelectorAll('input, select, textarea');
        let isValid = true;
        
        for (const input of inputs) {
            if (!this.validateField(input)) {
                isValid = false;
            }
        }
        
        // Additional step-specific validation
        if (this.currentStep === 5) {
            // Check if all required files are uploaded
            const requiredFiles = ['id_document', 'proof_residence', 'agency_ffc', 'agent_neab', 'agent_ffc'];
            for (const fileType of requiredFiles) {
                if (!this.uploadedFiles[fileType]) {
                    this.showToast('Missing Files', `Please upload all required documents`, 'warning');
                    isValid = false;
                    break;
                }
            }
        }
        
        return isValid;
    }
    
    validateField(input) {
        const value = input.value.trim();
        let isValid = true;
        let errorMessage = '';
        
        // Clear previous errors
        this.clearFieldError(input);
        
        // Required field validation
        if (input.hasAttribute('required') && !value) {
            isValid = false;
            errorMessage = 'This field is required';
        }
        
        // Email validation
        if (input.type === 'email' && value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                isValid = false;
                errorMessage = 'Please enter a valid email address';
            }
        }
        
        // Phone number validation
        if (input.type === 'tel' && value) {
            const phoneRegex = /^[\+]?[0-9\s\-\(\)]{7,15}$/;
            if (!phoneRegex.test(value)) {
                isValid = false;
                errorMessage = 'Please enter a valid phone number';
            }
        }
        
        // ID number validation
        if (input.id === 'id_number' && value) {
            const idType = document.getElementById('id_type').value;
            if (idType === 'National ID') {
                const nationalIdRegex = /^[0-9]{11}$/;
                if (!nationalIdRegex.test(value)) {
                    isValid = false;
                    errorMessage = 'National ID must be 11 digits';
                }
            } else if (idType === 'Passport') {
                const passportRegex = /^[A-Za-z0-9]{6,9}$/;
                if (!passportRegex.test(value)) {
                    isValid = false;
                    errorMessage = 'Passport number must be 6-9 alphanumeric characters';
                }
            }
        }
        
        // Date of birth validation
        if (input.type === 'date' && value) {
            const birthDate = new Date(value);
            const today = new Date();
            const age = today.getFullYear() - birthDate.getFullYear();
            
            if (age < 18 || age > 120) {
                isValid = false;
                errorMessage = 'Please enter a valid date of birth (18-120 years old)';
            }
        }
        
        // Show error if invalid
        if (!isValid) {
            this.showFieldError(input, errorMessage);
        }
        
        return isValid;
    }
    
    showFieldError(input, message) {
        input.classList.add('is-invalid');
        const feedback = input.parentElement.querySelector('.invalid-feedback');
        if (feedback) {
            feedback.textContent = message;
        }
    }
    
    clearFieldError(input) {
        input.classList.remove('is-invalid');
        input.classList.remove('is-valid');
        const feedback = input.parentElement.querySelector('.invalid-feedback');
        if (feedback) {
            feedback.textContent = '';
        }
    }
    
    async saveCurrentStep() {
        const stepData = this.getStepData(this.currentStep);
        
        try {
            const response = await this.makeRequest('save_step', {
                step: this.currentStep,
                csrf_token: this.csrfToken,
                ...stepData
            });
            
            if (response.success) {
                this.formData[`step_${this.currentStep}`] = stepData;
                return true;
            } else {
                if (response.errors) {
                    response.errors.forEach(error => {
                        this.showToast('Validation Error', error, 'warning');
                    });
                } else {
                    this.showToast('Error', response.message || 'Failed to save step', 'danger');
                }
                return false;
            }
        } catch (error) {
            console.error('Error saving step:', error);
            this.showToast('Error', 'Failed to save step data', 'danger');
            return false;
        }
    }
    
    getStepData(step) {
        const stepElement = document.getElementById(`step-${step}`);
        const inputs = stepElement.querySelectorAll('input, select, textarea');
        const data = {};
        
        inputs.forEach(input => {
            if (input.type === 'radio') {
                if (input.checked) {
                    data[input.name] = input.value;
                }
            } else if (input.type === 'checkbox') {
                data[input.name] = input.checked;
            } else {
                data[input.name] = input.value;
            }
        });
        
        return data;
    }
    
    loadFormData() {
        Object.keys(this.formData).forEach(stepKey => {
            const stepNumber = stepKey.replace('step_', '');
            const stepData = this.formData[stepKey];
            
            Object.keys(stepData).forEach(fieldName => {
                const input = document.querySelector(`#step-${stepNumber} [name="${fieldName}"]`);
                if (input) {
                    if (input.type === 'radio') {
                        const radioInput = document.querySelector(`#step-${stepNumber} [name="${fieldName}"][value="${stepData[fieldName]}"]`);
                        if (radioInput) {
                            radioInput.checked = true;
                        }
                    } else if (input.type === 'checkbox') {
                        input.checked = stepData[fieldName];
                    } else {
                        input.value = stepData[fieldName];
                        
                        // Trigger change event for town selects to auto-fill regions
                        if (input.id && input.id.includes('town')) {
                            input.dispatchEvent(new Event('change'));
                        }
                    }
                }
            });
        });
        
        // Load uploaded files info
        if (Array.isArray(this.uploadedFiles)) {
            this.uploadedFiles.forEach(file => {
                const input = document.querySelector(`[data-type="${file.file_type}"]`);
                if (input) {
                    const wrapper = input.closest('.file-upload-wrapper');
                    const fileInfo = wrapper.querySelector('.file-info');
                    const uploadLabel = wrapper.querySelector('.file-upload-label');
                    const filename = fileInfo.querySelector('.filename');
                    
                    filename.textContent = file.original_filename;
                    uploadLabel.classList.add('d-none');
                    fileInfo.classList.remove('d-none');
                    
                    this.uploadedFiles[file.file_type] = file;
                }
            });
        }
    }
    
    async submitForm() {
        // Final validation
        let allStepsValid = true;
        for (let step = 1; step <= this.totalSteps; step++) {
            const stepElement = document.getElementById(`step-${step}`);
            const inputs = stepElement.querySelectorAll('input, select, textarea');
            
            for (const input of inputs) {
                if (!this.validateField(input)) {
                    allStepsValid = false;
                }
            }
        }
        
        // Check required files
        const requiredFiles = ['id_document', 'proof_residence', 'agency_ffc', 'agent_neab', 'agent_ffc'];
        for (const fileType of requiredFiles) {
            if (!this.uploadedFiles[fileType]) {
                this.showToast('Missing Files', `Please upload ${fileType.replace('_', ' ')}`, 'warning');
                allStepsValid = false;
            }
        }
        
        if (!allStepsValid) {
            this.showToast('Validation Error', 'Please fix all errors before submitting', 'warning');
            return;
        }
        
        // Show confirmation
        if (!confirm('Are you sure you want to submit this agent application? You will not be able to make changes after submission.')) {
            return;
        }
        
        this.showLoading();
        
        try {
            const response = await this.makeRequest('submit_form', {
                csrf_token: this.csrfToken
            });
            
            if (response.success) {
                // Show success modal
                document.getElementById('applicationId').textContent = response.application_id;
                const successModal = new bootstrap.Modal(document.getElementById('successModal'));
                successModal.show();
                
                // Disable form
                document.getElementById('agentForm').classList.add('d-none');
            } else {
                this.showToast('Submission Error', response.message || 'Failed to submit application', 'danger');
            }
        } catch (error) {
            console.error('Form submission error:', error);
            this.showToast('Error', 'Failed to submit application', 'danger');
        } finally {
            this.hideLoading();
        }
    }
    
    async makeRequest(action, data) {
        const response = await fetch('ajax_handler.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: action,
                ...data
            })
        });
        
        if (!response.ok) {
            throw new Error('Network error');
        }
        
        const result = await response.json();
        return result;
    }
    
    showLoading() {
        document.getElementById('loadingOverlay').classList.remove('d-none');
    }
    
    hideLoading() {
        document.getElementById('loadingOverlay').classList.add('d-none');
    }
    
    showToast(title, message, type = 'info') {
        const toastContainer = document.getElementById('toastContainer');
        const toastId = 'toast-' + Date.now();
        
        const bgClass = type === 'success' ? 'bg-success' : 
                       type === 'danger' ? 'bg-danger' : 
                       type === 'warning' ? 'bg-warning' : 
                       'bg-info';
        
        const iconClass = type === 'success' ? 'bi-check-circle-fill' : 
                         type === 'danger' ? 'bi-exclamation-triangle-fill' : 
                         type === 'warning' ? 'bi-exclamation-triangle-fill' : 
                         'bi-info-circle-fill';
        
        const toastHtml = `
            <div id="${toastId}" class="toast ${bgClass} text-white" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="5000">
                <div class="toast-header ${bgClass} text-white">
                    <i class="bi ${iconClass} me-2"></i>
                    <strong class="me-auto">${title}</strong>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            </div>
        `;
        
        toastContainer.insertAdjacentHTML('beforeend', toastHtml);
        
        const toastElement = document.getElementById(toastId);
        const toast = new bootstrap.Toast(toastElement);
        toast.show();
        
        // Remove toast element after it's hidden
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
        });
    }
}

// Initialize the form when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AgentForm();
});

// Handle browser back/forward buttons
window.addEventListener('popstate', (e) => {
    if (e.state && e.state.step) {
        const form = window.agentForm;
        if (form) {
            form.goToStep(e.state.step);
        }
    }
});

// Auto-save form data periodically
setInterval(() => {
    const form = window.agentForm;
    if (form && form.currentStep) {
        // Save current step data silently
        form.saveCurrentStep().catch(() => {
            // Ignore errors for auto-save
        });
    }
}, 30000); // Auto-save every 30 seconds
