// Form Validation - Comprehensive validation logic for Seller Form

const FormValidation = {
    // Validation rules for each field
    validationRules: {
        // Personal Details
        surname: { required: true, minLength: 2, pattern: /^[a-zA-Z\s'-]+$/ },
        firstName: { required: true, minLength: 2, pattern: /^[a-zA-Z\s'-]+$/ },
        middleName: { pattern: /^[a-zA-Z\s'-]*$/ },
        maidenName: { pattern: /^[a-zA-Z\s'-]*$/ },
        dateOfBirth: { required: true, type: 'date', minAge: 18, maxAge: 120 },
        idType: { required: true },
        idNumber: { required: true, custom: 'validateIdNumber' },
        nationality: { required: true },
        gender: { required: true },

        // Marital Status
        maritalStatus: { required: true },

        // Spouse Details (conditional)
        spouseSurname: { conditional: 'maritalStatus=Married', minLength: 2, pattern: /^[a-zA-Z\s'-]+$/ },
        spouseFirstName: { conditional: 'maritalStatus=Married', minLength: 2, pattern: /^[a-zA-Z\s'-]+$/ },
        spouseDateOfBirth: { conditional: 'maritalStatus=Married', type: 'date', minAge: 18, maxAge: 120 },
        spouseIdType: { conditional: 'maritalStatus=Married' },
        spouseIdNumber: { conditional: 'maritalStatus=Married', custom: 'validateSpouseIdNumber' },
        spouseNationality: { conditional: 'maritalStatus=Married' },

        // Residential Address
        streetName: { required: true, minLength: 3 },
        region: { required: true },
        town: { required: true },
        email: { required: true, type: 'email' },
        mobileNumber: { required: true, custom: 'validatePhoneNumber' },

        // Next of Kin
        nokSurname: { required: true, minLength: 2, pattern: /^[a-zA-Z\s'-]+$/ },
        nokFirstName: { required: true, minLength: 2, pattern: /^[a-zA-Z\s'-]+$/ },
        nokContactNumber: { required: true, custom: 'validatePhoneNumber' },
        nokEmail: { required: true, type: 'email' },
        nokStreetName: { required: true, minLength: 3 },
        nokRegion: { required: true },
        nokTown: { required: true },

        // Sale Type
        saleType: { required: true },

        // Property Developer (conditional)
        developerName: { conditional: 'saleType=Property Development', minLength: 2 },
        propertyType: { conditional: 'saleType=Property Development' },

        // Property Details
        propertyDetailType: { required: true },
        landType: { required: true },
        landSize: { required: true, type: 'number', min: 1 },
        sellingPrice: { required: true, custom: 'validateCurrency' },
        propertyStreetName: { required: true, minLength: 3 },
        propertyRegion: { required: true },
        propertyTown: { required: true },

        // Existing Property Details (conditional)
        houseSize: { conditional: 'landType=Existing Property', type: 'number', min: 1 },
        rooms: { conditional: 'landType=Existing Property', type: 'number', min: 1, max: 50 },
        bathrooms: { conditional: 'landType=Existing Property', type: 'number', min: 1, max: 20 },

        // Documents (handled separately for file validation)
        idDocument: { required: true, type: 'file' },
        proofOfResidence: { required: true, type: 'file' },
        titleDeed: { required: true, type: 'file' },
        marriageCertificateDoc: { conditional: 'maritalStatus=Married', type: 'file' },

        // Property Images
        propertyImages: { required: true, type: 'file', multiple: true },

        // Declaration
        certificationDeclaration: { required: true, type: 'checkbox' },
        authorizationDeclaration: { required: true, type: 'checkbox' },
        indemnificationDeclaration: { required: true, type: 'checkbox' },
        commissionFeesDeclaration: { required: true, type: 'checkbox' },
        propertyRightsDeclaration: { required: true, type: 'checkbox' },
        signatureLocation: { required: true, minLength: 2 },
        signatureDate: { required: true, type: 'date' },
        signatureType: { required: true },
        signatureFile: { conditional: 'signatureType=upload', type: 'file' },
        otpNumber: { conditional: 'signatureType=otp', pattern: /^\d{6}$/ }
    },

    // Error messages
    errorMessages: {
        required: 'This field is required',
        minLength: 'Must be at least {min} characters long',
        maxLength: 'Must be no more than {max} characters long',
        pattern: 'Please enter a valid value',
        email: 'Please enter a valid email address',
        number: 'Please enter a valid number',
        min: 'Value must be at least {min}',
        max: 'Value must be no more than {max}',
        minAge: 'Must be at least {min} years old',
        maxAge: 'Must be no more than {max} years old',
        date: 'Please enter a valid date',
        file: 'Please select a file',
        fileSize: 'File size must be less than {max}MB',
        fileType: 'File type not allowed. Allowed types: {types}',
        phone: 'Please enter a valid Namibian phone number',
        currency: 'Please enter a valid amount',
        idNumber: 'Please enter a valid ID number',
        passport: 'Please enter a valid passport number',
        checkbox: 'You must agree to this declaration',
        otp: 'Please enter a 6-digit OTP code'
    },

    // File type restrictions
    allowedFileTypes: {
        documents: ['pdf', 'jpg', 'jpeg', 'png'],
        images: ['jpg', 'jpeg', 'png', 'webp'],
        videos: ['mp4', 'mov', 'avi'],
        signature: ['jpg', 'jpeg', 'png']
    },

    // File size limits (in MB)
    fileSizeLimits: {
        documents: 10,
        images: 10,
        videos: 100,
        signature: 5
    },

    // Initialize validation
    init() {
        this.setupRealTimeValidation();
        this.setupFormSubmissionValidation();
        this.setupFileValidation();
        this.setupConditionalValidation();
    },

    // Setup real-time validation
    setupRealTimeValidation() {
        const form = document.getElementById('sellerApplicationForm');
        if (!form) return;

        // Add event listeners for real-time validation
        form.addEventListener('blur', (e) => {
            if (e.target.matches('input, select, textarea')) {
                this.validateField(e.target);
            }
        }, true);

        form.addEventListener('change', (e) => {
            if (e.target.matches('input[type="radio"], input[type="checkbox"], select')) {
                this.validateField(e.target);
            }
        });

        form.addEventListener('input', (e) => {
            if (e.target.matches('input[type="text"], input[type="email"], input[type="tel"], textarea')) {
                // Debounce validation for text inputs
                clearTimeout(e.target.validationTimeout);
                e.target.validationTimeout = setTimeout(() => {
                    this.validateField(e.target);
                }, 500);
            }
        });
    },

    // Setup form submission validation
    setupFormSubmissionValidation() {
        const form = document.getElementById('sellerApplicationForm');
        if (!form) return;

        form.addEventListener('submit', (e) => {
            e.preventDefault();
            if (this.validateForm()) {
                // Form is valid, proceed with submission
                SellerForm.submitApplication();
            }
        });
    },

    // Setup file validation
    setupFileValidation() {
        document.addEventListener('change', (e) => {
            if (e.target.type === 'file') {
                this.validateFileField(e.target);
            }
        });
    },

    // Setup conditional validation
    setupConditionalValidation() {
        // Marital status changes
        document.getElementById('maritalStatus')?.addEventListener('change', (e) => {
            this.updateConditionalFields('maritalStatus', e.target.value);
        });

        // Sale type changes
        const saleTypeRadios = document.querySelectorAll('input[name="saleType"]');
        saleTypeRadios.forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.updateConditionalFields('saleType', e.target.value);
            });
        });

        // Land type changes
        document.getElementById('landType')?.addEventListener('change', (e) => {
            this.updateConditionalFields('landType', e.target.value);
        });

        // Signature type changes
        const signatureTypeRadios = document.querySelectorAll('input[name="signatureType"]');
        signatureTypeRadios.forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.updateConditionalFields('signatureType', e.target.value);
            });
        });
    },

    // Update conditional field requirements
    updateConditionalFields(triggerField, value) {
        Object.keys(this.validationRules).forEach(fieldName => {
            const rule = this.validationRules[fieldName];
            if (rule.conditional) {
                const [conditionField, conditionValue] = rule.conditional.split('=');
                const field = document.querySelector(`[name="${fieldName}"]`);
                
                if (field && conditionField === triggerField) {
                    if (value === conditionValue) {
                        field.setAttribute('required', 'required');
                        field.closest('.form-group, .mb-3')?.classList.remove('d-none');
                    } else {
                        field.removeAttribute('required');
                        this.clearFieldValidation(field);
                    }
                }
            }
        });

        // Special handling for spouse section
        if (triggerField === 'maritalStatus') {
            const spouseSection = document.getElementById('spouseDetails');
            if (spouseSection) {
                if (value === 'Married') {
                    spouseSection.classList.remove('d-none');
                } else {
                    spouseSection.classList.add('d-none');
                    // Clear spouse fields
                    spouseSection.querySelectorAll('input, select').forEach(field => {
                        field.value = '';
                        this.clearFieldValidation(field);
                    });
                }
            }
        }

        // Special handling for property developer section
        if (triggerField === 'saleType') {
            const developerSection = document.getElementById('propertyDeveloperDetails');
            if (developerSection) {
                if (value === 'Property Development') {
                    developerSection.classList.remove('d-none');
                } else {
                    developerSection.classList.add('d-none');
                    developerSection.querySelectorAll('input, select').forEach(field => {
                        field.value = '';
                        this.clearFieldValidation(field);
                    });
                }
            }
        }

        // Special handling for existing property details
        if (triggerField === 'landType') {
            const existingPropertySection = document.getElementById('existingPropertyDetails');
            if (existingPropertySection) {
                if (value === 'Existing Property') {
                    existingPropertySection.classList.remove('d-none');
                } else {
                    existingPropertySection.classList.add('d-none');
                    existingPropertySection.querySelectorAll('input, select, textarea').forEach(field => {
                        field.value = '';
                        this.clearFieldValidation(field);
                    });
                }
            }
        }
    },

    // Validate individual field
    validateField(field) {
        const fieldName = field.name;
        const rule = this.validationRules[fieldName];
        
        if (!rule) return true;

        // Check if field is conditionally required
        if (rule.conditional && !this.isConditionalFieldRequired(rule.conditional)) {
            this.clearFieldValidation(field);
            return true;
        }

        const value = this.getFieldValue(field);
        const errors = [];

        // Required validation
        if (rule.required && this.isEmpty(value)) {
            errors.push(this.errorMessages.required);
        }

        // Skip other validations if field is empty and not required
        if (this.isEmpty(value) && !rule.required) {
            this.clearFieldValidation(field);
            return true;
        }

        // Type-specific validation
        if (rule.type) {
            const typeError = this.validateFieldType(field, value, rule.type);
            if (typeError) errors.push(typeError);
        }

        // Length validation
        if (rule.minLength && value.length < rule.minLength) {
            errors.push(this.errorMessages.minLength.replace('{min}', rule.minLength));
        }
        if (rule.maxLength && value.length > rule.maxLength) {
            errors.push(this.errorMessages.maxLength.replace('{max}', rule.maxLength));
        }

        // Pattern validation
        if (rule.pattern && !rule.pattern.test(value)) {
            errors.push(this.errorMessages.pattern);
        }

        // Numeric validation
        if (rule.type === 'number') {
            const numValue = parseFloat(value);
            if (rule.min !== undefined && numValue < rule.min) {
                errors.push(this.errorMessages.min.replace('{min}', rule.min));
            }
            if (rule.max !== undefined && numValue > rule.max) {
                errors.push(this.errorMessages.max.replace('{max}', rule.max));
            }
        }

        // Age validation for date fields
        if (rule.minAge || rule.maxAge) {
            const age = FormData.calculateAge(value);
            if (rule.minAge && age < rule.minAge) {
                errors.push(this.errorMessages.minAge.replace('{min}', rule.minAge));
            }
            if (rule.maxAge && age > rule.maxAge) {
                errors.push(this.errorMessages.maxAge.replace('{max}', rule.maxAge));
            }
        }

        // Custom validation
        if (rule.custom) {
            const customError = this[rule.custom](field, value);
            if (customError) errors.push(customError);
        }

        // Display validation result
        if (errors.length > 0) {
            this.displayFieldError(field, errors[0]);
            return false;
        } else {
            this.displayFieldSuccess(field);
            return true;
        }
    },

    // Validate file field
    validateFileField(field) {
        const files = Array.from(field.files);
        if (files.length === 0) {
            if (field.hasAttribute('required')) {
                this.displayFieldError(field, this.errorMessages.file);
                return false;
            }
            return true;
        }

        const fieldType = this.getFileFieldType(field.name);
        const allowedTypes = this.allowedFileTypes[fieldType] || this.allowedFileTypes.documents;
        const maxSize = this.fileSizeLimits[fieldType] || this.fileSizeLimits.documents;

        for (let file of files) {
            // File size validation
            if (file.size > maxSize * 1024 * 1024) {
                this.displayFieldError(field, this.errorMessages.fileSize.replace('{max}', maxSize));
                return false;
            }

            // File type validation
            const fileExtension = file.name.split('.').pop().toLowerCase();
            if (!allowedTypes.includes(fileExtension)) {
                this.displayFieldError(field, this.errorMessages.fileType.replace('{types}', allowedTypes.join(', ')));
                return false;
            }
        }

        this.displayFieldSuccess(field);
        this.updateFilePreview(field, files);
        return true;
    },

    // Get file field type for validation
    getFileFieldType(fieldName) {
        if (fieldName.includes('Image') || fieldName === 'propertyImages') return 'images';
        if (fieldName.includes('Video') || fieldName === 'propertyVideos') return 'videos';
        if (fieldName.includes('signature') || fieldName === 'signatureFile') return 'signature';
        return 'documents';
    },

    // Update file preview
    updateFilePreview(field, files) {
        const previewContainer = document.getElementById(field.id + 'Preview');
        if (!previewContainer) return;

        previewContainer.innerHTML = '';

        files.forEach((file, index) => {
            const preview = document.createElement('div');
            preview.className = 'file-preview';

            if (file.type.startsWith('image/')) {
                const img = document.createElement('img');
                img.src = URL.createObjectURL(file);
                img.alt = file.name;
                preview.appendChild(img);
            } else if (file.type.startsWith('video/')) {
                const video = document.createElement('video');
                video.src = URL.createObjectURL(file);
                video.controls = true;
                preview.appendChild(video);
            } else {
                preview.innerHTML = `
                    <div class="file-info">
                        <i class="fas fa-file-pdf fa-2x mb-2"></i>
                        <div>${file.name}</div>
                        <small>${this.formatFileSize(file.size)}</small>
                    </div>
                `;
            }

            // Add remove button
            const removeBtn = document.createElement('button');
            removeBtn.className = 'remove-btn';
            removeBtn.innerHTML = '<i class="fas fa-times"></i>';
            removeBtn.onclick = () => this.removeFilePreview(field, index);
            preview.appendChild(removeBtn);

            previewContainer.appendChild(preview);
        });
    },

    // Remove file preview
    removeFilePreview(field, index) {
        // Create new FileList without the removed file
        const dt = new DataTransfer();
        const files = Array.from(field.files);
        
        files.forEach((file, i) => {
            if (i !== index) dt.items.add(file);
        });
        
        field.files = dt.files;
        this.updateFilePreview(field, Array.from(field.files));
        
        if (field.files.length === 0 && field.hasAttribute('required')) {
            this.displayFieldError(field, this.errorMessages.file);
        }
    },

    // Format file size for display
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    // Custom validation methods
    validateIdNumber(field, value) {
        const idType = document.getElementById('idType')?.value;
        if (idType === 'National ID') {
            return FormData.isValidNamibianId(value) ? null : this.errorMessages.idNumber;
        } else if (idType === 'Passport') {
            return FormData.isValidPassport(value) ? null : this.errorMessages.passport;
        }
        return null;
    },

    validateSpouseIdNumber(field, value) {
        const idType = document.getElementById('spouseIdType')?.value;
        if (idType === 'National ID') {
            return FormData.isValidNamibianId(value) ? null : this.errorMessages.idNumber;
        } else if (idType === 'Passport') {
            return FormData.isValidPassport(value) ? null : this.errorMessages.passport;
        }
        return null;
    },

    validatePhoneNumber(field, value) {
        // Remove all non-digit characters
        const cleaned = value.replace(/\D/g, '');
        
        // Namibian phone number patterns
        const patterns = [
            /^264\d{8,9}$/, // +264 format without +
            /^0\d{8,9}$/, // Local format with 0
            /^\d{8,9}$/ // Without country code or leading 0
        ];
        
        const isValid = patterns.some(pattern => pattern.test(cleaned));
        return isValid ? null : this.errorMessages.phone;
    },

    validateCurrency(field, value) {
        const numValue = parseFloat(value.replace(/[^\d.]/g, ''));
        if (isNaN(numValue) || numValue <= 0) {
            return this.errorMessages.currency;
        }
        return null;
    },

    // Helper methods
    getFieldValue(field) {
        if (field.type === 'checkbox' || field.type === 'radio') {
            return field.checked ? field.value : '';
        }
        return field.value.trim();
    },

    isEmpty(value) {
        return value === null || value === undefined || value === '';
    },

    isConditionalFieldRequired(condition) {
        const [conditionField, conditionValue] = condition.split('=');
        const triggerField = document.querySelector(`[name="${conditionField}"]`);
        
        if (!triggerField) return false;
        
        if (triggerField.type === 'radio') {
            const checkedRadio = document.querySelector(`[name="${conditionField}"]:checked`);
            return checkedRadio && checkedRadio.value === conditionValue;
        }
        
        return triggerField.value === conditionValue;
    },

    validateFieldType(field, value, type) {
        switch (type) {
            case 'email':
                return FormData.isValidEmail(value) ? null : this.errorMessages.email;
            case 'number':
                return !isNaN(parseFloat(value)) ? null : this.errorMessages.number;
            case 'date':
                const date = new Date(value);
                return !isNaN(date.getTime()) ? null : this.errorMessages.date;
            case 'checkbox':
                return field.checked ? null : this.errorMessages.checkbox;
            default:
                return null;
        }
    },

    // Display validation results
    displayFieldError(field, message) {
        field.classList.add('is-invalid');
        field.classList.remove('is-valid');
        
        const feedback = field.parentNode.querySelector('.invalid-feedback');
        if (feedback) {
            feedback.textContent = message;
            feedback.style.display = 'block';
        }
    },

    displayFieldSuccess(field) {
        field.classList.add('is-valid');
        field.classList.remove('is-invalid');
        
        const feedback = field.parentNode.querySelector('.invalid-feedback');
        if (feedback) {
            feedback.style.display = 'none';
        }
    },

    clearFieldValidation(field) {
        field.classList.remove('is-valid', 'is-invalid');
        
        const feedback = field.parentNode.querySelector('.invalid-feedback');
        if (feedback) {
            feedback.style.display = 'none';
        }
    },

    // Validate entire form
    validateForm() {
        const form = document.getElementById('sellerApplicationForm');
        if (!form) return false;

        let isValid = true;
        const fields = form.querySelectorAll('input, select, textarea');
        
        fields.forEach(field => {
            if (!this.validateField(field)) {
                isValid = false;
            }
        });

        // Validate file fields
        const fileFields = form.querySelectorAll('input[type="file"]');
        fileFields.forEach(field => {
            if (!this.validateFileField(field)) {
                isValid = false;
            }
        });

        // Add form validation class
        form.classList.add('was-validated');

        return isValid;
    },

    // Validate specific step
    validateStep(stepNumber) {
        const step = document.getElementById(`step-${stepNumber}`);
        if (!step) return true;

        let isValid = true;
        const fields = step.querySelectorAll('input, select, textarea');
        
        fields.forEach(field => {
            if (!this.validateField(field)) {
                isValid = false;
            }
        });

        return isValid;
    },

    // Clear all validation
    clearAllValidation() {
        const form = document.getElementById('sellerApplicationForm');
        if (!form) return;

        form.classList.remove('was-validated');
        const fields = form.querySelectorAll('input, select, textarea');
        
        fields.forEach(field => {
            this.clearFieldValidation(field);
        });
    }
};

// Initialize validation when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    FormValidation.init();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FormValidation;
}
