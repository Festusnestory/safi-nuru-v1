// Seller Form - Main form handling and API interactions

const SellerForm = {
    apiBaseUrl: '../api',
    csrfToken: null,
    additionalDocumentCount: 0,
    houseTypeCount: 0,

    // Initialize the seller form
    init() {
        this.getCSRFToken();
        this.bindEvents();
        this.setupInteractions();
        this.setupFileHandling();
        this.setupDynamicSections();
    },

    // Get CSRF token
    getCSRFToken() {
        const metaTag = document.querySelector('meta[name="csrf-token"]');
        if (metaTag) {
            this.csrfToken = metaTag.getAttribute('content');
        } else {
            this.generateCSRFToken();
        }
    },

    // Generate CSRF token
    async generateCSRFToken() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/csrf-token`);
            const data = await response.json();
            this.csrfToken = data.token;
        } catch (error) {
            console.error('Error fetching CSRF token:', error);
        }
    },

    // Bind form events
    bindEvents() {
        // Set current date for signature
        const signatureDateInput = document.getElementById('signatureDate');
        if (signatureDateInput) {
            signatureDateInput.value = FormData.getCurrentDate();
        }

        // Phone number formatting
        this.setupPhoneFormatting();
        
        // Currency formatting
        this.setupCurrencyFormatting();
        
        // Region-town dependencies
        this.setupRegionTownDependencies();
        
        // Age calculation
        this.setupAgeCalculation();
    },

    // Setup form interactions
    setupInteractions() {
        // Marital status interactions
        this.setupMaritalStatusInteractions();
        
        // Sale type interactions
        this.setupSaleTypeInteractions();
        
        // Land type interactions
        this.setupLandTypeInteractions();
        
        // Signature type interactions
        this.setupSignatureTypeInteractions();
    },

    // Setup phone number formatting
    setupPhoneFormatting() {
        const phoneInputs = document.querySelectorAll('input[type="tel"]');
        phoneInputs.forEach(input => {
            input.addEventListener('input', (e) => {
                const formatted = FormData.formatPhoneNumber(e.target.value);
                if (formatted !== e.target.value) {
                    e.target.value = formatted;
                }
            });
        });
    },

    // Setup currency formatting
    setupCurrencyFormatting() {
        const currencyInputs = document.querySelectorAll('#sellingPrice');
        currencyInputs.forEach(input => {
            input.addEventListener('input', (e) => {
                // Remove all non-digit and non-decimal characters
                let value = e.target.value.replace(/[^\d.]/g, '');
                
                // Ensure only one decimal point
                const parts = value.split('.');
                if (parts.length > 2) {
                    value = parts[0] + '.' + parts.slice(1).join('');
                }
                
                // Format with commas
                if (value) {
                    const number = parseFloat(value);
                    if (!isNaN(number)) {
                        // Format while typing
                        const formatted = number.toLocaleString('en-US');
                        e.target.value = formatted;
                    }
                }
            });

            input.addEventListener('blur', (e) => {
                const value = parseFloat(e.target.value.replace(/[^\d.]/g, ''));
                if (!isNaN(value)) {
                    e.target.value = value.toLocaleString('en-US', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    });
                }
            });
        });
    },

    // Setup region-town dependencies
    setupRegionTownDependencies() {
        // Main residential address
        const regionSelect = document.getElementById('region');
        if (regionSelect) {
            regionSelect.addEventListener('change', (e) => {
                FormData.populateTowns(e.target.value, 'town');
            });
        }

        // Next of kin address
        const nokRegionSelect = document.getElementById('nokRegion');
        if (nokRegionSelect) {
            nokRegionSelect.addEventListener('change', (e) => {
                FormData.populateTowns(e.target.value, 'nokTown');
            });
        }

        // Property address
        const propertyRegionSelect = document.getElementById('propertyRegion');
        if (propertyRegionSelect) {
            propertyRegionSelect.addEventListener('change', (e) => {
                FormData.populateTowns(e.target.value, 'propertyTown');
            });
        }
    },

    // Setup age calculation
    setupAgeCalculation() {
        const dobInput = document.getElementById('dateOfBirth');
        if (dobInput) {
            dobInput.addEventListener('change', (e) => {
                const age = FormData.calculateAge(e.target.value);
                let ageDisplay = document.getElementById('ageDisplay');
                if (!ageDisplay) {
                    ageDisplay = document.createElement('div');
                    ageDisplay.id = 'ageDisplay';
                    dobInput.parentNode.appendChild(ageDisplay);
                }
                
                ageDisplay.textContent = `Age: ${age} years`;
                ageDisplay.className = age >= 18 ? 'small text-success' : 'small text-danger';
            });
        }
    },

    // Setup marital status interactions
    setupMaritalStatusInteractions() {
        const maritalStatusSelect = document.getElementById('maritalStatus');
        if (maritalStatusSelect) {
            maritalStatusSelect.addEventListener('change', (e) => {
                const spouseSection = document.getElementById('spouseDetails');
                const marriageCertCard = document.getElementById('marriageCertificateCard');
                
                if (e.target.value === 'Married') {
                    spouseSection?.classList.remove('d-none');
                    marriageCertCard?.style.setProperty('display', 'block');
                    
                    // Make spouse fields required
                    const spouseFields = spouseSection?.querySelectorAll('input, select');
                    spouseFields?.forEach(field => {
                        if (['spouseSurname', 'spouseFirstName', 'spouseDateOfBirth'].includes(field.id)) {
                            field.setAttribute('required', 'required');
                        }
                    });
                } else {
                    spouseSection?.classList.add('d-none');
                    marriageCertCard?.style.setProperty('display', 'none');
                    
                    // Clear and make spouse fields not required
                    const spouseFields = spouseSection?.querySelectorAll('input, select');
                    spouseFields?.forEach(field => {
                        field.removeAttribute('required');
                        field.value = '';
                        FormValidation.clearFieldValidation(field);
                    });
                }
            });
        }
    },

    // Setup sale type interactions
    setupSaleTypeInteractions() {
        const saleTypeCards = document.querySelectorAll('.sale-type-card');
        const saleTypeRadios = document.querySelectorAll('input[name="saleType"]');
        
        saleTypeCards.forEach(card => {
            card.addEventListener('click', () => {
                const radio = card.querySelector('input[type="radio"]');
                if (radio) {
                    radio.checked = true;
                    radio.dispatchEvent(new Event('change'));
                }
            });
        });

        saleTypeRadios.forEach(radio => {
            radio.addEventListener('change', (e) => {
                // Update card selection visuals
                saleTypeCards.forEach(card => {
                    card.classList.remove('selected');
                    if (card.dataset.type === e.target.value) {
                        card.classList.add('selected');
                    }
                });

                // Show/hide property developer details
                const developerSection = document.getElementById('propertyDeveloperDetails');
                if (e.target.value === 'Property Development') {
                    developerSection?.classList.remove('d-none');
                } else {
                    developerSection?.classList.add('d-none');
                    // Clear developer fields
                    developerSection?.querySelectorAll('input, select').forEach(field => {
                        field.value = '';
                        FormValidation.clearFieldValidation(field);
                    });
                }
            });
        });
    },

    // Setup land type interactions
    setupLandTypeInteractions() {
        const landTypeSelect = document.getElementById('landType');
        if (landTypeSelect) {
            landTypeSelect.addEventListener('change', (e) => {
                const existingPropertySection = document.getElementById('existingPropertyDetails');
                
                if (e.target.value === 'Existing Property') {
                    existingPropertySection?.classList.remove('d-none');
                } else {
                    existingPropertySection?.classList.add('d-none');
                    // Clear existing property fields
                    existingPropertySection?.querySelectorAll('input, select, textarea').forEach(field => {
                        field.value = '';
                        FormValidation.clearFieldValidation(field);
                    });
                }
            });
        }
    },

    // Setup signature type interactions
    setupSignatureTypeInteractions() {
        const signatureMethodCards = document.querySelectorAll('.signature-method-card');
        const signatureTypeRadios = document.querySelectorAll('input[name="signatureType"]');
        
        signatureMethodCards.forEach(card => {
            card.addEventListener('click', () => {
                const radio = card.querySelector('input[type="radio"]');
                if (radio) {
                    radio.checked = true;
                    radio.dispatchEvent(new Event('change'));
                }
            });
        });

        signatureTypeRadios.forEach(radio => {
            radio.addEventListener('change', (e) => {
                // Update card selection visuals
                signatureMethodCards.forEach(card => {
                    card.classList.remove('selected');
                    if (card.dataset.method === e.target.value) {
                        card.classList.add('selected');
                    }
                });

                // Show/hide signature method containers
                const uploadContainer = document.getElementById('signatureUploadContainer');
                const otpContainer = document.getElementById('otpContainer');
                
                if (e.target.value === 'upload') {
                    uploadContainer?.classList.remove('d-none');
                    otpContainer?.classList.add('d-none');
                } else if (e.target.value === 'otp') {
                    uploadContainer?.classList.add('d-none');
                    otpContainer?.classList.remove('d-none');
                }
            });
        });

        // Setup OTP send button
        const sendOTPButton = document.getElementById('sendOTP');
        if (sendOTPButton) {
            sendOTPButton.addEventListener('click', () => {
                this.sendOTP();
            });
        }
    },

    // Setup file handling
    setupFileHandling() {
        // Drag and drop for upload zones
        this.setupDragAndDrop();
        
        // File input changes
        document.addEventListener('change', (e) => {
            if (e.target.type === 'file') {
                this.handleFileSelection(e.target);
            }
        });
    },

    // Setup drag and drop
    setupDragAndDrop() {
        const uploadZones = document.querySelectorAll('.upload-zone');
        
        uploadZones.forEach(zone => {
            const fileInput = zone.querySelector('input[type="file"]');
            if (!fileInput) return;

            zone.addEventListener('dragover', (e) => {
                e.preventDefault();
                zone.classList.add('dragover');
            });

            zone.addEventListener('dragleave', () => {
                zone.classList.remove('dragover');
            });

            zone.addEventListener('drop', (e) => {
                e.preventDefault();
                zone.classList.remove('dragover');
                
                const files = Array.from(e.dataTransfer.files);
                this.handleDroppedFiles(fileInput, files);
            });

            zone.addEventListener('click', () => {
                fileInput.click();
            });
        });
    },

    // Handle file selection
    handleFileSelection(fileInput) {
        const files = Array.from(fileInput.files);
        this.processFiles(fileInput, files);
    },

    // Handle dropped files
    handleDroppedFiles(fileInput, files) {
        // Create new DataTransfer to set files
        const dt = new DataTransfer();
        files.forEach(file => dt.items.add(file));
        fileInput.files = dt.files;
        
        this.processFiles(fileInput, files);
    },

    // Process files
    processFiles(fileInput, files) {
        if (files.length === 0) return;

        // Update document upload card visual state
        const card = fileInput.closest('.document-upload-card');
        if (card && files.length > 0) {
            card.classList.add('has-file');
        }

        // Handle different file input types
        if (fileInput.id === 'propertyImages') {
            this.handlePropertyImages(files);
        } else if (fileInput.id === 'propertyVideos') {
            this.handlePropertyVideos(files);
        } else {
            this.handleDocumentUpload(fileInput, files);
        }
    },

    // Handle property images
    handlePropertyImages(files) {
        const container = document.getElementById('imagePreviewContainer');
        if (!container) return;

        container.innerHTML = '';
        
        files.forEach((file, index) => {
            if (file.type.startsWith('image/')) {
                const preview = this.createImagePreview(file, index, 'propertyImages');
                container.appendChild(preview);
            }
        });
    },

    // Handle property videos
    handlePropertyVideos(files) {
        const container = document.getElementById('videoPreviewContainer');
        if (!container) return;

        container.innerHTML = '';
        
        files.forEach((file, index) => {
            if (file.type.startsWith('video/')) {
                const preview = this.createVideoPreview(file, index, 'propertyVideos');
                container.appendChild(preview);
            }
        });
    },

    // Handle document upload
    handleDocumentUpload(fileInput, files) {
        const previewContainer = document.getElementById(fileInput.id + 'Preview');
        if (!previewContainer) return;

        previewContainer.innerHTML = '';
        
        files.forEach((file, index) => {
            const preview = this.createDocumentPreview(file, index, fileInput.id);
            previewContainer.appendChild(preview);
        });
    },

    // Create image preview
    createImagePreview(file, index, inputId) {
        const preview = document.createElement('div');
        preview.className = 'col-md-3 mb-3';
        
        const img = document.createElement('img');
        img.src = URL.createObjectURL(file);
        img.className = 'img-fluid rounded';
        img.alt = file.name;
        
        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'btn btn-danger btn-sm position-absolute top-0 end-0 m-2';
        removeBtn.innerHTML = '<i class="fas fa-times"></i>';
        removeBtn.onclick = () => this.removeFile(inputId, index);
        
        preview.innerHTML = `
            <div class="position-relative">
                ${img.outerHTML}
                ${removeBtn.outerHTML}
                <div class="small text-muted mt-1">${file.name}</div>
            </div>
        `;
        
        return preview;
    },

    // Create video preview
    createVideoPreview(file, index, inputId) {
        const preview = document.createElement('div');
        preview.className = 'col-md-4 mb-3';
        
        const video = document.createElement('video');
        video.src = URL.createObjectURL(file);
        video.className = 'w-100 rounded';
        video.controls = true;
        
        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'btn btn-danger btn-sm position-absolute top-0 end-0 m-2';
        removeBtn.innerHTML = '<i class="fas fa-times"></i>';
        removeBtn.onclick = () => this.removeFile(inputId, index);
        
        preview.innerHTML = `
            <div class="position-relative">
                ${video.outerHTML}
                ${removeBtn.outerHTML}
                <div class="small text-muted mt-1">${file.name}</div>
            </div>
        `;
        
        return preview;
    },

    // Create document preview
    createDocumentPreview(file, index, inputId) {
        const preview = document.createElement('div');
        preview.className = 'file-preview d-flex align-items-center p-2 border rounded mb-2';
        
        const icon = file.type.includes('pdf') ? 'fa-file-pdf text-danger' : 
                    file.type.includes('image') ? 'fa-file-image text-primary' : 
                    'fa-file text-secondary';
        
        preview.innerHTML = `
            <i class="fas ${icon} fa-2x me-3"></i>
            <div class="flex-grow-1">
                <div class="fw-bold">${file.name}</div>
                <small class="text-muted">${this.formatFileSize(file.size)}</small>
            </div>
            <button type="button" class="btn btn-outline-danger btn-sm" onclick="SellerForm.removeFile('${inputId}', ${index})">
                <i class="fas fa-trash"></i>
            </button>
        `;
        
        return preview;
    },

    // Remove file
    removeFile(inputId, index) {
        const fileInput = document.getElementById(inputId);
        if (!fileInput) return;
        
        const dt = new DataTransfer();
        const files = Array.from(fileInput.files);
        
        files.forEach((file, i) => {
            if (i !== index) dt.items.add(file);
        });
        
        fileInput.files = dt.files;
        
        // Refresh previews
        this.processFiles(fileInput, Array.from(fileInput.files));
        
        // Update validation
        FormValidation.validateFileField(fileInput);
    },

    // Format file size
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    // Setup dynamic sections
    setupDynamicSections() {
        // Additional documents
        const addDocButton = document.getElementById('addAdditionalDocument');
        if (addDocButton) {
            addDocButton.addEventListener('click', () => {
                this.addAdditionalDocument();
            });
        }

        // House types for development
        const addHouseTypeButton = document.getElementById('addHouseType');
        if (addHouseTypeButton) {
            addHouseTypeButton.addEventListener('click', () => {
                this.addHouseType();
            });
        }
    },

    // Add additional document
    addAdditionalDocument() {
        this.additionalDocumentCount++;
        const container = document.getElementById('additionalDocuments');
        
        const docItem = document.createElement('div');
        docItem.className = 'additional-doc-item';
        docItem.innerHTML = `
            <button type="button" class="remove-additional-doc" onclick="this.closest('.additional-doc-item').remove()">
                <i class="fas fa-times"></i>
            </button>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Document Name</label>
                    <input type="text" class="form-control" name="additionalDocName[]" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Document File</label>
                    <input type="file" class="form-control" name="additionalDocFile[]" accept=".pdf,.jpg,.jpeg,.png" required>
                </div>
            </div>
        `;
        
        container.appendChild(docItem);
    },

    // Add house type
    addHouseType() {
        this.houseTypeCount++;
        const container = document.getElementById('houseTypesList');
        
        const houseTypeItem = document.createElement('div');
        houseTypeItem.className = 'house-type-item';
        houseTypeItem.innerHTML = `
            <button type="button" class="remove-house-type" onclick="this.closest('.house-type-item').remove()">
                <i class="fas fa-times"></i>
            </button>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">House Type</label>
                    <select class="form-select" name="houseType[]" required>
                        <option value="">Select House Type</option>
                        ${FormData.houseTypes.map(type => `<option value="${type}">${type}</option>`).join('')}
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Number of Units</label>
                    <input type="number" class="form-control" name="houseTypeUnits[]" min="1" required>
                </div>
            </div>
        `;
        
        container.appendChild(houseTypeItem);
    },

    // Send OTP
    async sendOTP() {
        const mobileNumber = document.getElementById('mobileNumber').value;
        
        if (!mobileNumber) {
            alert('Please enter your mobile number first in Step 3: Residential Address');
            return;
        }

        try {
            this.showLoadingOverlay();
            
            const response = await fetch(`${this.apiBaseUrl}/send-otp`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.csrfToken
                },
                body: JSON.stringify({ 
                    mobile_number: mobileNumber,
                    type: 'seller_signature'
                })
            });

            const result = await response.json();

            if (response.ok && result.success) {
                alert('OTP sent successfully to your mobile number!');
                
                // Start countdown
                this.startOTPCountdown();
            } else {
                alert(result.message || 'Failed to send OTP. Please try again.');
            }

        } catch (error) {
            console.error('Error sending OTP:', error);
            alert('Network error. Please check your connection and try again.');
        } finally {
            this.hideLoadingOverlay();
        }
    },

    // Start OTP countdown
    startOTPCountdown() {
        const sendButton = document.getElementById('sendOTP');
        let countdown = 60;
        
        sendButton.disabled = true;
        
        const interval = setInterval(() => {
            sendButton.textContent = `Resend OTP (${countdown}s)`;
            countdown--;
            
            if (countdown < 0) {
                clearInterval(interval);
                sendButton.disabled = false;
                sendButton.textContent = 'Send OTP';
            }
        }, 1000);
    },

    // Submit application
    async submitApplication() {
        try {
            // Validate entire form
            if (!FormValidation.validateForm()) {
                const errorStep = FormStepper.navigateToStepWithError();
                if (errorStep) {
                    alert(`Please correct the errors in Step ${errorStep} before submitting.`);
                }
                return;
            }

            this.showLoadingOverlay();

            // Prepare form data
            const formData = this.prepareFormData();

            // Submit to API
            const response = await fetch(`${this.apiBaseUrl}/applications/sellers`, {
                method: 'POST',
                body: formData // Using FormData for file uploads
            });

            const result = await response.json();

            if (response.ok && result.success) {
                this.handleSubmissionSuccess(result);
            } else {
                this.handleSubmissionError(result.error || 'Submission failed');
            }

        } catch (error) {
            console.error('Submission error:', error);
            this.handleSubmissionError('Network error occurred. Please try again.');
        } finally {
            this.hideLoadingOverlay();
        }
    },

    // Prepare form data for submission
    prepareFormData() {
        const form = document.getElementById('sellerApplicationForm');
        const formData = new FormData(form);
        
        // Add CSRF token
        formData.append('_token', this.csrfToken);
        
        // Add metadata
        formData.append('application_type', 'seller');
        formData.append('submission_timestamp', new Date().toISOString());
        
        // Add step completion data
        formData.append('completed_steps', JSON.stringify(Array.from(FormStepper.completedSteps)));
        
        return formData;
    },

    // Handle submission success
    handleSubmissionSuccess(result) {
        // Clear saved data
        FormData.clearFormData();
        FormStepper.clearProgress();
        
        // Show success modal
        const modal = new bootstrap.Modal(document.getElementById('successModal'));
        
        // Update application number
        const applicationNumber = document.getElementById('applicationNumber');
        if (applicationNumber && result.application_number) {
            applicationNumber.textContent = result.application_number;
        }
        
        modal.show();
    },

    // Handle submission error
    handleSubmissionError(error) {
        alert(`Error: ${error}\n\nPlease check your information and try again.`);
    },

    // Show loading overlay
    showLoadingOverlay() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.remove('d-none');
        }
    },

    // Hide loading overlay
    hideLoadingOverlay() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.add('d-none');
        }
    }
};

// Initialize seller form when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    SellerForm.init();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SellerForm;
}
