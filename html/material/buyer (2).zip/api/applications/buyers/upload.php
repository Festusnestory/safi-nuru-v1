<?php
require_once '../../../config/pdo.php';

$uploadDir = '../../../uploads/buyers/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['file'])) {
    $buyer_id = $_POST['buyer_id'] ?? 0;
    $doc_type = $_POST['doc_type'] ?? 'other';

    $fileName = uniqid() . '-' . basename($_FILES['file']['name']);
    $filePath = $uploadDir . $fileName;

    if (move_uploaded_file($_FILES['file']['tmp_name'], $filePath)) {
        $stmt = $pdo->prepare("INSERT INTO buyer_documents (buyer_id, doc_type, file_path) VALUES (?, ?, ?)");
        $stmt->execute([$buyer_id, $doc_type, 'uploads/buyers/' . $fileName]);

        echo json_encode(['success' => true, 'path' => 'uploads/buyers/' . $fileName]);
    } else {
        echo json_encode(['success' => false, 'error' => 'File upload failed']);
    }
}
