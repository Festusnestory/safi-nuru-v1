<?php
// ===============================================================
// File: api/applications/buyers/index.php
// Purpose: Save buyer multi-step form (personal, spouse, kin, property, docs)
// Author: Festus (Refactored for FormData + JSON support)
// ===============================================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-CSRF-TOKEN');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require_once '../../../config/pdo.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Custom logging function
function debugLog($message) {
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $message\n";
    error_log($logMessage, 3, '../../../logs/debug.log');
}

debugLog("=== API CALL STARTED ===");
debugLog("Request Method: " . $_SERVER['REQUEST_METHOD']);
debugLog("Content Type: " . ($_SERVER['CONTENT_TYPE'] ?? 'Not Set'));

// Check if data is being received
$rawInput = file_get_contents('php://input');
debugLog("Raw input received: " . strlen($rawInput) . " characters");
if ($rawInput) {
    debugLog("Raw input content (first 500 chars): " . substr($rawInput, 0, 500));
}

// ===============================================================
// Generate Unique Application Number
// ===============================================================
function generateApplicationNumber($pdo) {
    $prefix = 'BUY';
    $date = date('Ymd');
    $count = $pdo->query("SELECT COUNT(*) FROM buyers")->fetchColumn() + 1;
    return sprintf('%s-%s-%04d', $prefix, $date, $count);
}

try {
    debugLog("Testing database connection...");
    if (!$pdo) {
        debugLog("ERROR: PDO connection is null");
        throw new Exception("Database connection failed");
    }
    debugLog("Database connection successful");

    // Test a simple query
    $testResult = $pdo->query("SELECT 1")->fetch();
    debugLog("Database test query result: " . (empty($testResult) ? 'FAILED' : 'SUCCESS'));

    debugLog("Starting transaction...");
    $pdo->beginTransaction();
    debugLog("Transaction started successfully");

    // ===============================================================
    // Handle both JSON and multipart/form-data
    // ===============================================================
    debugLog("Checking for data...");
    
    if (!empty($_POST)) {
        debugLog("Using POST data");
        $data = $_POST;
    } else {
        debugLog("Using JSON input");
        $rawData = file_get_contents('php://input');
        debugLog("Raw JSON data: " . $rawData);
        $data = json_decode($rawData, true);
        debugLog("JSON decoded successfully: " . (json_last_error() === JSON_ERROR_NONE ? 'YES' : 'NO'));
        if (json_last_error() !== JSON_ERROR_NONE) {
            debugLog("JSON Error: " . json_last_error_msg());
        }
    }

    debugLog("Data variable type: " . gettype($data));
    if (is_array($data)) {
        debugLog("Data keys: " . implode(', ', array_keys($data)));
        debugLog("Data array size: " . count($data));
    } else {
        debugLog("Data is not an array, it's: " . gettype($data));
    }

    if (!$data) {
        debugLog("ERROR: Data is null or empty");
        throw new Exception("Invalid input data");
    }
    
    debugLog("Data validation passed");

    // ===============================================================
    // Insert Main Buyer Info
    // ===============================================================
    debugLog("Generating application number...");
    $application_number = generateApplicationNumber($pdo);
    debugLog("Generated application number: " . $application_number);

    $stmt = $pdo->prepare("
        INSERT INTO buyers (
            application_number, full_name, date_of_birth, id_type, id_number,
            marital_status, phone, email, region, town, address,
            employment_type, employer_name, position, monthly_income,
            property_value, down_payment, loan_amount
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    debugLog("Preparing main buyer insert statement...");
    
    $executeParams = [
        $application_number,
        $data['full_name'] ?? null,
        $data['date_of_birth'] ?? null,
        $data['id_type'] ?? null,
        $data['id_number'] ?? null,
        $data['marital_status'] ?? null,
        $data['phone'] ?? null,
        $data['email'] ?? null,
        $data['region'] ?? null,
        $data['town'] ?? null,
        $data['address'] ?? null,
        $data['employment_type'] ?? null,
        $data['employer_name'] ?? null,
        $data['position'] ?? null,
        $data['monthly_income'] ?? 0,
        $data['property_value'] ?? 0,
        $data['down_payment'] ?? 0,
        $data['loan_amount'] ?? 0
    ];
    
    debugLog("Execute parameters: " . json_encode($executeParams, JSON_PRETTY_PRINT));
    
    $result = $stmt->execute($executeParams);
    debugLog("Main buyer insert result: " . ($result ? 'SUCCESS' : 'FAILURE'));
    
    if (!$result) {
        $errorInfo = $stmt->errorInfo();
        debugLog("SQL Error: " . implode(' - ', $errorInfo));
        throw new Exception("Failed to insert buyer: " . implode(' - ', $errorInfo));
    }

    $buyer_id = $pdo->lastInsertId();
    debugLog("Inserted buyer ID: " . $buyer_id);
    
    if (!$buyer_id || $buyer_id == 0) {
        debugLog("ERROR: Invalid buyer ID returned");
        throw new Exception("Failed to get buyer ID after insert");
    }

    // ===============================================================
    // Insert Spouse Info (if married)
    // ===============================================================
    if (!empty($data['marital_status']) && strtolower($data['marital_status']) === 'married') {
        if (!empty($data['buyer_spouse'])) {
            $stmt = $pdo->prepare("
                INSERT INTO buyer_spouse (buyer_id, full_name, id_passport, date_of_birth)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([
                $buyer_id,
                $data['buyer_spouse']['full_name'] ?? null,
                $data['buyer_spouse']['id_passport'] ?? null,
                $data['buyer_spouse']['date_of_birth'] ?? null
            ]);
        }
    }

    // ===============================================================
    // Insert Next of Kin Info
    // ===============================================================
    if (!empty($data['buyer_next_of_kin'])) {
        $stmt = $pdo->prepare("
            INSERT INTO buyer_next_of_kin (buyer_id, full_name, relationship, phone, region, town, address)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $buyer_id,
            $data['buyer_next_of_kin']['full_name'] ?? null,
            $data['buyer_next_of_kin']['relationship'] ?? null,
            $data['buyer_next_of_kin']['phone'] ?? null,
            $data['buyer_next_of_kin']['region'] ?? null,
            $data['buyer_next_of_kin']['town'] ?? null,
            $data['buyer_next_of_kin']['address'] ?? null
        ]);
    }

    // ===============================================================
    // Insert Preferred Areas
    // ===============================================================
    $preferredAreas = [];
    if (!empty($data['preferredAreas'])) {
        $preferredAreas = is_array($data['preferredAreas']) ? $data['preferredAreas'] : json_decode($data['preferredAreas'], true);
    }
    if ($preferredAreas) {
        $stmt = $pdo->prepare("
            INSERT INTO buyer_preferred_areas (buyer_id, region, town, location, suburb)
            VALUES (?, ?, ?, ?, ?)
        ");
        foreach ($preferredAreas as $area) {
            $stmt->execute([
                $buyer_id,
                $area['region'] ?? null,
                $area['town'] ?? null,
                $area['location'] ?? null,
                $area['suburb'] ?? null
            ]);
        }
    }

    // ===============================================================
    // Insert Declarations (if any)
    // ===============================================================
    $declarations = [];
    if (!empty($data['declarations'])) {
        $declarations = is_array($data['declarations']) ? $data['declarations'] : json_decode($data['declarations'], true);
    }
    if ($declarations) {
        $stmt = $pdo->prepare("
            INSERT INTO buyer_declarations (buyer_id, declaration)
            VALUES (?, ?)
        ");
        foreach ($declarations as $decl) {
            $stmt->execute([
                $buyer_id,
                $decl ?? null
            ]);
        }
    }

    // ===============================================================
    // Insert Documents Info (from JSON)
    // ===============================================================
    if (!empty($data['buyer_documents']) && is_array($data['buyer_documents'])) {
        $stmt = $pdo->prepare("
            INSERT INTO buyer_documents (buyer_id, doc_type, file_path, file_name, file_type, file_size)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        foreach ($data['buyer_documents'] as $doc) {
            $stmt->execute([
                $buyer_id,
                $doc['doc_type'] ?? 'Other',
                $doc['file_path'] ?? null,
                $doc['file_name'] ?? null,
                $doc['file_type'] ?? null,
                $doc['file_size'] ?? 0
            ]);
        }
    }

    // ===============================================================
    // Commit Transaction
    // ===============================================================
    debugLog("Committing transaction...");
    $commitResult = $pdo->commit();
    debugLog("Commit result: " . ($commitResult ? 'SUCCESS' : 'FAILURE'));
    
    if (!$commitResult) {
        $errorInfo = $pdo->errorInfo();
        debugLog("Commit Error: " . implode(' - ', $errorInfo));
        throw new Exception("Failed to commit transaction: " . implode(' - ', $errorInfo));
    }

    echo json_encode([
        'success' => true,
        'application_number' => $application_number,
        'buyer_id' => $buyer_id,
        'message' => 'Buyer application submitted successfully.'
    ]);

} catch (Exception $e) {
    debugLog("EXCEPTION CAUGHT: " . $e->getMessage());
    debugLog("Exception trace: " . $e->getTraceAsString());
    
    if (isset($pdo) && $pdo->inTransaction()) {
        debugLog("Rolling back transaction...");
        $pdo->rollBack();
        debugLog("Transaction rolled back");
    }
    
    $errorResponse = [
        'success' => false,
        'error' => $e->getMessage()
    ];
    
    debugLog("Sending error response: " . json_encode($errorResponse));
    echo json_encode($errorResponse);
}
