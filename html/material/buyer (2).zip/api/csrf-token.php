<?php
// ===============================================================
// File: api/csrf-token.php
// Purpose: Generate and return CSRF token
// ===============================================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Generate a simple CSRF token
$token = bin2hex(random_bytes(32));

echo json_encode([
    'token' => $token,
    'timestamp' => time()
]);