/**
 * Agent Form JavaScript Handler
 * Handles multi-step form navigation, validation, and submission
 */

class AgentForm {
    constructor() {
        this.currentStep = 1;
        this.totalSteps = 5;
        this.formData = {};
        this.uploadedFiles = {}; // Temporarily store selected files
        this.agentId = null;
    }

    init() {
        this.setupEventListeners();
        this.setupTownRegionMapping();
        this.updateProgressIndicator();
    }

    setupEventListeners() {
        document.getElementById('nextBtn').addEventListener('click', () => this.nextStep());
        document.getElementById('prevBtn').addEventListener('click', () => this.prevStep());
        document.getElementById('agentForm').addEventListener('submit', (e) => this.handleSubmit(e));
        document.getElementById('gross_income').addEventListener('input', () => this.calculateNetPay());
        document.getElementById('total_deductions').addEventListener('input', () => this.calculateNetPay());
        document.getElementById('residential_town').addEventListener('change', (e) => this.populateRegion(e.target.value, 'residential_region'));
        this.setupFileUploadHandlers();
    }

    setupTownRegionMapping() {
        this.townRegionMapping = {
            'Windhoek': 'Khomas',
            'Swakopmund': 'Erongo',
            'Walvis Bay': 'Erongo',
            'Rundu': 'Kavango',
            'Oshakati': 'Oshana',
            'Otjiwarongo': 'Otjozondjupa',
            'Rehoboth': 'Khomas'
        };
    }

    setupFileUploadHandlers() {
        const fileInputs = ['id_document', 'proof_residence', 'agency_ffc', 'agent_neab', 'agent_ffc'];
        fileInputs.forEach(inputId => {
            document.getElementById(inputId).addEventListener('change', (e) => this.handleFileUpload(e));
        });
    }

    nextStep() {
        if (this.validateCurrentStep()) {
            this.saveCurrentStepData();
            if (this.currentStep < this.totalSteps) {
                this.currentStep++;
                this.showStep(this.currentStep);
                this.updateProgressIndicator();
            }
        }
    }

    prevStep() {
        if (this.currentStep > 1) {
            this.currentStep--;
            this.showStep(this.currentStep);
            this.updateProgressIndicator();
        }
    }

    showStep(step) {
        document.querySelectorAll('.form-step').forEach(el => el.classList.add('d-none'));
        document.getElementById(`step${step}`).classList.remove('d-none');

        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const submitBtn = document.getElementById('submitBtn');

        prevBtn.style.display = step > 1 ? 'block' : 'none';
        if (step === this.totalSteps) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'block';
        } else {
            nextBtn.style.display = 'block';
            submitBtn.style.display = 'none';
        }

        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    updateProgressIndicator() {
        document.querySelectorAll('.step-item').forEach((item, index) => {
            const step = index + 1;
            item.classList.toggle('active', step === this.currentStep);
            item.classList.toggle('completed', step < this.currentStep);
        });
    }

    validateCurrentStep() {
        const stepEl = document.getElementById(`step${this.currentStep}`);
        const requiredFields = stepEl.querySelectorAll('[required]');
        let isValid = true;

        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                this.showFieldError(field, 'This field is required');
                isValid = false;
            } else this.clearFieldError(field);
        });

        if (this.currentStep === 1) isValid = this.validatePersonalDetails() && isValid;
        else if (this.currentStep === 2) isValid = this.validateContactInfo() && isValid;
        else if (this.currentStep === 4) isValid = this.validateEmployment() && isValid;

        return isValid;
    }

    validatePersonalDetails() {
        let isValid = true;
        const dob = document.getElementById('date_of_birth').value;
        if (dob) {
            const age = this.calculateAge(dob);
            if (age < 18 || age > 120) {
                this.showFieldError(document.getElementById('date_of_birth'), 'Age must be between 18 and 120');
                isValid = false;
            }
        }

        const idType = document.getElementById('id_type').value;
        const idNumber = document.getElementById('id_number').value;
        if (idType === 'National ID' && idNumber && !/^\d{11}$/.test(idNumber)) {
            this.showFieldError(document.getElementById('id_number'), 'National ID must be 11 digits');
            isValid = false;
        }
        return isValid;
    }

    validateContactInfo() {
        let isValid = true;
        const email = document.getElementById('email').value;
        if (email && !this.isValidEmail(email)) {
            this.showFieldError(document.getElementById('email'), 'Please enter a valid email address');
            isValid = false;
        }
        const phone = document.getElementById('mobile_number').value;
        if (phone && !this.isValidPhone(phone)) {
            this.showFieldError(document.getElementById('mobile_number'), 'Please enter a valid phone number');
            isValid = false;
        }
        return isValid;
    }

    validateEmployment() {
        let isValid = true;
        const grossIncome = parseFloat(document.getElementById('gross_income').value) || 0;
        const netPay = parseFloat(document.getElementById('net_pay').value) || 0;
        if (grossIncome > 0 && netPay > 0 && netPay > grossIncome) {
            this.showFieldError(document.getElementById('net_pay'), 'Net pay cannot be greater than gross income');
            isValid = false;
        }
        return isValid;
    }

    calculateAge(dateString) {
        const today = new Date();
        const birthDate = new Date(dateString);
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) age--;
        return age;
    }

    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    isValidPhone(phone) {
        return /^[\+]?[0-9\s\-\(\)]{7,15}$/.test(phone);
    }

    calculateNetPay() {
        const grossIncome = parseFloat(document.getElementById('gross_income').value) || 0;
        const deductions = parseFloat(document.getElementById('total_deductions').value) || 0;
        const netPay = Math.max(0, grossIncome - deductions);
        document.getElementById('net_pay').value = netPay.toFixed(2);
    }

    populateRegion(town, regionFieldId) {
        const regionField = document.getElementById(regionFieldId);
        if (this.townRegionMapping[town]) regionField.value = this.townRegionMapping[town];
    }

    showFieldError(field, message) {
        this.clearFieldError(field);
        field.classList.add('is-invalid');
        const div = document.createElement('div');
        div.className = 'invalid-feedback';
        div.textContent = message;
        field.parentNode.appendChild(div);
    }

    clearFieldError(field) {
        field.classList.remove('is-invalid');
        const div = field.parentNode.querySelector('.invalid-feedback');
        if (div) div.remove();
    }

    saveCurrentStepData() {
        const stepEl = document.getElementById(`step${this.currentStep}`);
        const inputs = stepEl.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            if (input.type !== 'file') this.formData[input.name] = input.value;
        });
    }

    handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        const allowedTypes = [
            'application/pdf','application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'image/jpeg','image/jpg','image/png','image/gif','image/tiff','image/bmp'
        ];

        if (!allowedTypes.includes(file.type)) {
            alert('Invalid file type. Only PDF/DOC/DOCX/Images allowed.');
            event.target.value = '';
            return;
        }

        const maxSize = 10 * 1024 * 1024;
        if (file.size > maxSize) {
            alert('File size must be less than 10MB');
            event.target.value = '';
            return;
        }

        this.uploadedFiles[event.target.name] = file;
        this.showUploadProgress(event.target.name, 'File selected, will upload on submission', 'info');
    }

    showUploadProgress(fileType, message, status = 'info') {
        const fileInput = document.getElementById(fileType);
        const feedback = document.createElement('div');
        feedback.className = 'upload-feedback mt-1';
        feedback.innerHTML = `<small class="text-${status}">${message}</small>`;
        const existing = fileInput.parentNode.querySelector('.upload-feedback');
        if (existing) existing.remove();
        fileInput.parentNode.appendChild(feedback);
    }

    async handleSubmit(event) {
        event.preventDefault();

        // Validate all steps
        for (let step = 1; step <= this.totalSteps; step++) {
            this.currentStep = step;
            if (!this.validateCurrentStep()) {
                this.showStep(step);
                return;
            }
        }

        // Ensure required files
        const requiredFiles = ['id_document', 'proof_residence', 'agency_ffc', 'agent_neab', 'agent_ffc'];
        const missingFiles = requiredFiles.filter(ft => !this.uploadedFiles[ft]);
        if (missingFiles.length > 0) {
            alert('Please upload all required documents before submitting.');
            return;
        }

        const submitBtn = document.getElementById('submitBtn');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Submitting...';
        submitBtn.disabled = true;

        try {
            const formData = new FormData();
            formData.append('action', 'submit_application');

            Object.keys(this.formData).forEach(key => formData.append(key, this.formData[key]));
            Object.keys(this.uploadedFiles).forEach(key => formData.append(key, this.uploadedFiles[key]));

            const response = await fetch('./../api/applications/agent/index.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                this.agentId = result.agent_id;
                this.showSuccessMessage({
                    agent_id: result.agent_id,
                    application_id: result.application_id,
                    status: 'Submitted'
                });
            } else {
                throw new Error(result.error || 'Unknown server error');
            }
        } catch (error) {
            console.error('Submission error:', error);
            alert('Application submission failed: ' + error.message);
        } finally {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    }

    showSuccessMessage(data) {
        const html = `
            <div class="alert alert-success">
                <h4><i class="bi bi-check-circle"></i> Application Submitted Successfully!</h4>
                <p>Your agent application has been submitted.</p>
                <div class="mt-3">
                    <strong>Agent ID:</strong> ${data.agent_id}<br>
                    <strong>Application ID:</strong> ${data.application_id || 'N/A'}<br>
                    <strong>Status:</strong> ${data.status || 'Submitted'}
                </div>
            </div>
        `;
        document.querySelector('.card-body').innerHTML = html;
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// Make globally accessible
window.AgentForm = AgentForm;
