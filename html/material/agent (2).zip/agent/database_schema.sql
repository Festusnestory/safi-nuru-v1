-- Agent Form Database Schema
-- Database tables for the agent registration form in the portal

-- Agent form sessions table for managing form state
CREATE TABLE IF NOT EXISTS agent_form_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id VARCHAR(32) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    current_step TINYINT DEFAULT 1,
    csrf_token VARCHAR(64),
    form_data JSON,
    expires_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_session_user (session_id, user_id),
    INDEX idx_expires (expires_at),
    FOREIGN KEY (user_id) REFERENCES admin_users(id) ON DELETE CASCADE
);

-- Agent applications table for storing submitted applications
CREATE TABLE IF NOT EXISTS agent_applications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    application_id VARCHAR(20) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    session_id VARCHAR(32),
    
    -- Personal Details (Step 1)
    surname VARCHAR(100) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    maiden_name VARCHAR(100),
    date_of_birth DATE NOT NULL,
    id_type ENUM('National ID', 'Passport') NOT NULL,
    id_number VARCHAR(20) NOT NULL,
    nationality VARCHAR(100) NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    
    -- Residential Address (Step 2)
    residential_erf_no VARCHAR(50),
    residential_street_name VARCHAR(200),
    residential_suburb VARCHAR(100),
    residential_location VARCHAR(100),
    residential_town VARCHAR(100) NOT NULL,
    residential_region VARCHAR(100),
    email VARCHAR(255) NOT NULL,
    mobile_number VARCHAR(20) NOT NULL,
    po_box VARCHAR(50),
    
    -- Next of Kin (Step 3)
    kin_surname VARCHAR(100) NOT NULL,
    kin_first_name VARCHAR(100) NOT NULL,
    kin_contact_number VARCHAR(20) NOT NULL,
    kin_email VARCHAR(255),
    kin_erf_no VARCHAR(50),
    kin_street_name VARCHAR(200),
    kin_suburb VARCHAR(100),
    kin_location VARCHAR(100),
    kin_town VARCHAR(100),
    kin_region VARCHAR(100),
    
    -- Employment Details (Step 4)
    company_name VARCHAR(200) NOT NULL,
    job_title VARCHAR(150) NOT NULL,
    employment_number VARCHAR(50),
    gross_income DECIMAL(12, 2) NOT NULL,
    total_deductions DECIMAL(12, 2) NOT NULL,
    net_pay DECIMAL(12, 2) NOT NULL,
    employment_email VARCHAR(255),
    employment_erf_no VARCHAR(50),
    employment_street_name VARCHAR(200),
    employment_suburb VARCHAR(100),
    employment_location VARCHAR(100),
    employment_town VARCHAR(100),
    employment_region VARCHAR(100),
    
    -- Meta data
    form_data JSON,
    status ENUM('pending', 'reviewed', 'approved', 'rejected', 'incomplete') DEFAULT 'pending',
    assigned_to INT,
    review_notes TEXT,
    reviewed_at DATETIME,
    reviewed_by INT,
    submitted_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_application_id (application_id),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_submitted (submitted_at),
    INDEX idx_email (email),
    INDEX idx_id_number (id_number),
    FOREIGN KEY (user_id) REFERENCES admin_users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to) REFERENCES admin_users(id) ON DELETE SET NULL,
    FOREIGN KEY (reviewed_by) REFERENCES admin_users(id) ON DELETE SET NULL
);

-- Agent uploaded files table for storing file information
CREATE TABLE IF NOT EXISTS agent_uploaded_files (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id VARCHAR(32) NOT NULL,
    user_id INT NOT NULL,
    application_id VARCHAR(20),
    file_type ENUM('id_document', 'proof_residence', 'agency_ffc', 'agent_neab', 'agent_ffc') NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    stored_filename VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_session_file_type (session_id, file_type),
    INDEX idx_session_user (session_id, user_id),
    INDEX idx_application_id (application_id),
    INDEX idx_file_type (file_type),
    FOREIGN KEY (user_id) REFERENCES admin_users(id) ON DELETE CASCADE,
    FOREIGN KEY (application_id) REFERENCES agent_applications(application_id) ON DELETE CASCADE
);

-- Add agent permissions to the existing permissions system
INSERT IGNORE INTO permissions (name, description) VALUES 
('manage_agents', 'Manage agent applications and registrations'),
('view_agents', 'View agent applications'),
('approve_agents', 'Approve or reject agent applications');

-- Add agent module to system modules
INSERT IGNORE INTO system_modules (module_name, display_name, description, is_active) VALUES 
('agents', 'Agent Management', 'Manage real estate agent applications and registrations', 1);

-- Grant permissions to admin role (assuming role_id 1 is admin)
INSERT IGNORE INTO role_permissions (role_id, permission_id) 
SELECT 1, id FROM permissions WHERE name IN ('manage_agents', 'view_agents', 'approve_agents');
